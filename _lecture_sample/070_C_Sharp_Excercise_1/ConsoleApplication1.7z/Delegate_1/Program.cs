﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate_1
{
    delegate bool Cal<T>(T a, T b);
    class Program
    {
        static bool Ascend (int a, int b) //where T : IComparable<T>
        {
            return (a < b) ? true : false;
        }
        //static bool Descend<T>(T a, T b) where T : IComparable<T>
        //{
        //    return a.CompareTo(b) * -1;
        //}
       

        static void BubbleSort<T>( T [] DataSet, Cal<T> compute )
        {
            for( int i= 0; i < DataSet.Length-1; i++)
            {
                for(int j = 0; j < DataSet.Length- (i+1); j++)
                {
                    if(compute(DataSet[j], DataSet[j+1]))
                    {
                        T tmp = DataSet[j+1];
                        DataSet[j+1] = DataSet[j];
                        DataSet[j] = tmp;
                    }
                }
            }
        }

        static void Main(string[] args)
        {
            int[] array = {3,6,9,1,7,8 };
            BubbleSort<int>(array, new Cal<int>(Ascend));
            for( int i=0; i <array.Length; i++)
            {
                Console.Write("{0} ", array[i]);
            }
            //Console.WriteLine("\n");
            //BubbleSort<int>(array, new Cal<int>(Descend));
            //for (int i = 0; i < array.Length; i++)
            //{
            //    Console.Write("{0} ", array[i]);
            //}

            //Cal<int> cal = new Cal<int>(Add);// (a,b) => { return a + b; };                  
            //Console.WriteLine(cal(1,2));

            //Cal<float> cal2 = new Cal<float>(Add);
            //Console.WriteLine(cal2(1.0f, 2.0f));
        }
    }
}
