﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// language integrated query // sql
namespace linq
{
    class Program
    {
        public class Student
        {
            public string name { get; set; }            
            public int id { get; set; }
            public List<int> Scores;            
        }
        static List<Student> students = new List<Student>
        {
            new Student { name = "aaa", id= 100, Scores = new List<int> {30,20,95 } },
            new Student { name = "abb", id= 200, Scores = new List<int> {60,95,30 } },
            new Student { name = "ccc", id= 300, Scores = new List<int> {92,97,98 } },
            new Student { name = "cdd", id= 400, Scores = new List<int> {95,20,30 } },
            new Student { name = "aee", id= 500, Scores = new List<int> {30,98,90 } },
        };
        #region
        public ArrayList Comute( int [] data)
        {
            ArrayList ar = new ArrayList();
            for( int i= 0; i < data.Length; i++)
            {
                if( data[i] %2 == 0 )
                {
                    //yield return data[i];
                    ar.Add(data[i]);
                }
            }
            return ar;
        }
        #endregion
        static void Main(string[] args)
        {
            // 1)총점 계산
            var query =
                from n in students
                let total =     n.Scores[0] +
                                n.Scores[1] +
                                n.Scores[2]
                select  total;

            double average = query.Average();

            foreach (int k in query)
                Console.WriteLine("{0} ", k );

            // 평균 보다 높은 학생 검색
            var query2 =
                from n in students
                let total = n.Scores[0] +
                                n.Scores[1] +
                                n.Scores[2]
                where average < total 
                select n;

            foreach (var  std in query2)
                Console.WriteLine("{0} ", std.name);

            //var query = ;
            ////IEnumerable<string> query = 
            ////List<string> query =
            //var query =
            //    from student in students
            //    //group student by student.name[0];
            //    where (student.Scores[0] > 0 &&
            //    //student.Scores[1] > 0 &&
            //    //student.Scores[2] > 0)
            //    select student.name;//).ToList();


            #region
            //int [] ar = new int[] {0,1,2,3,4,5,6 };
            //var query =
            //    (from int n in ar
            //    where (n % 2 == 0)
            //    select n).ToList();

            ////IEnumerable<int> query2 =
            //var query2 =
            //    from int n in ar
            //    where (n % 2 == 0)
            //    select n;
            //List<int> ar2 = query2.ToList();
            #endregion
            //foreach ( Student k in query)
            //foreach (var group in query)
            //{
            //    Console.WriteLine("{0}:", group.Key);
            //    foreach (var student in group)
            //    {
            //        Console.WriteLine("{0}:{1}",
            //            student.name, student.id);
            //    }
            //    //Console.WriteLine("{0}:{1}:{2} {3} {4}",
            //    //    k.name, k.id, k.Scores[0],
            //    //    k.Scores[1],
            //    //    k.Scores[2]);
            //}
            // from   절
            // where  절
            // select 절
        }
    }
}
