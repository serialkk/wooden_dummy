﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Action_0
{
    delegate void Msg(string msg);
    delegate void Msg2();
    delegate void Add(int a, int b, int c, string msg);

    delegate int MsgRet();
    delegate int MsgRet1(string msg);
    delegate int AddRet(int a, int b, int c, string msg);

    public class Days : IEnumerable
    {
        public IList userData;
  
        public void SetData( object data)
        {
            userData.Add(data);
        }
        public string name = "aa";
        public int iID = 0;
        public int iLevel = 100;
        public string email ="ddd@dddd.com";

        public string [] days = { "sun", "mon", "tue","wed", "thu", "fri", "sat"};

        private int[] iDays = { 0,1,2,3,4,5,6};

        public IEnumerator GetEnumerator()
        {
            yield return name;
            yield return iID;
            yield return iLevel;
            yield return email;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Days day = new Days();
            foreach (var iValue in day.userData)
            {
                Console.WriteLine("{0}", iValue);
            }

            //// 공변성(Covariance) :  할당 호환성이 유지된다.
            //// string -> Object
            //IEnumerable<string> strings = new List<string>();
            //IEnumerable<Object> string4 = strings;

            //// 반공변성( Contravariance ) : 할당 호환성이 뒤집인다.
            //// object -> string
            //Action<Object> actString = MessageObj;
            //Action<string> actString4 = actString;

            //int ?  aaa = null;
            //if(aaa.HasValue)
            //{
            //    Console.WriteLine("{0}",aaa.Value);
            //}


            //var tup = new Tuple<string, int,string, string>(
            //    "홍길동", 30,"구로구 1022", "010-3333-333");
            //Console.WriteLine("{0}, {1} {2} ", 
            //    tup.Item1, tup.Item2, tup.Item3);


            //Action MsgAction = Message;
            //Process(()=> Console.WriteLine("kkk"));

            ////Msg msg = new Msg(Message);
            ////msg("kgca");
            ////Action MsgAction = Message;
            //Action Msg3 = () => Console.WriteLine("kkk");

            //MsgAction();
            //Action<string> actString = MessageString;
            //actString("kgca");

            //Action<int,int,int,string> act4 = Add4;
            //act4(1,2,3,"kgca");

            //Func<int> func1 = Message1;
            //Func<int,string> func2 = Message2;
            //Func<int,int,int, string,int> func3 = Add5;
        }

        static void MessageString(string msg)
        {
            Console.WriteLine(msg);
        }
        static void Message()
        {
            Console.WriteLine("kgca");
        }
        static void MessageObj(Object a)
        {
            Console.WriteLine("kgca");
        }
        static int Message1()
        {
            return 1;
        }
        static string Message2(int a)
        {
            return "kgca";
        }
        static void Add4(int a, int b, int c, string d)
        {
            Console.WriteLine("kgca");
        }
        static int Add5(int a, int b, int c, string d)
        {
            Console.WriteLine("kgca");
            return 0;
        }
        static void Process(Action act)
        {
            act();
        }

        static System.Collections.IEnumerable PrintF()
        {
            for( int i=0; i < 10; i++)
            {
                yield return i;
            }
            //Console.WriteLine("1---");
            //yield return 1;
            //Console.WriteLine("2---");
            //yield return 2;
            //Console.WriteLine("3---");
            //yield return 3;
        }
      
    }
}
