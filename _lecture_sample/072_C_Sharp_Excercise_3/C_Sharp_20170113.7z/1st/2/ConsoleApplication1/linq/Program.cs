﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// language integrated query // sql
namespace linq
{
    class Program
    {
        public class Student
        {
            public string name { get; set; }            
            public int id { get; set; }
            public List<int> Scores;            
        }
        static List<Student> students = new List<Student>
        {
            new Student { name = "aaa", id= 100, Scores = new List<int> {30,20,95 } },
            new Student { name = "bbb", id= 200, Scores = new List<int> {60,95,30 } },
            new Student { name = "ccc", id= 300, Scores = new List<int> {30,90,70 } },
            new Student { name = "ddd", id= 400, Scores = new List<int> {95,20,30 } },
            new Student { name = "eee", id= 500, Scores = new List<int> {30,98,90 } },
        };
        #region
        public ArrayList Comute( int [] data)
        {
            ArrayList ar = new ArrayList();
            for( int i= 0; i < data.Length; i++)
            {
                if( data[i] %2 == 0 )
                {
                    //yield return data[i];
                    ar.Add(data[i]);
                }
            }
            return ar;
        }
        #endregion
        static void Main(string[] args)
        {
            IEnumerable<Student> query = 
                from student in students
                where student.Scores[0] > 90
                select student;

            
            #region
            //int [] ar = new int[] {0,1,2,3,4,5,6 };
            //var query =
            //    (from int n in ar
            //    where (n % 2 == 0)
            //    select n).ToList();

            ////IEnumerable<int> query2 =
            //var query2 =
            //    from int n in ar
            //    where (n % 2 == 0)
            //    select n;
            //List<int> ar2 = query2.ToList();
            #endregion
            foreach ( Student k in query)
            {
                Console.WriteLine("{0}:{1}", k.name, k.id);
            }
            // from   절
            // where  절
            // select 절
        }
    }
}
