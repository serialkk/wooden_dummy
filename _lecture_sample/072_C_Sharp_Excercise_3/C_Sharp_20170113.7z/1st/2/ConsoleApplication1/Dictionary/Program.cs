﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> data =
                new Dictionary<string, string>();
            data.Add("aaa", "1000");
            data.Add("bbb", "2000");
            data.Add("ccc", "3000");
            data["ddd"] = "4000";
            Console.WriteLine("{0}", data["aaa"] );
            Console.WriteLine("{0}", data["bbb"]);

            string value = "";
            if( data.TryGetValue("ddd", out value))
            {
                Console.WriteLine(value);
            }

            if (data.ContainsKey("ddd"))
            {
                Console.WriteLine(data["ddd"]);
            }

            //foreach(KeyValuePair<string, string> v in  data)
            foreach ( var v in data)
            {
                Console.WriteLine(v.Key,  v.Value);
            }

            data.Remove("ccc");

            data.Clear();            
        }
    }
}
