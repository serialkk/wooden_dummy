﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate_0
{   
    class MyEventArgs : EventArgs
    {
        public  int i;
        public int j;
        public MyEventArgs( int a, int b)
        {
            i = a;
            j = b;
        }
    } 
    class ProcessData
    {
        public void OnEventHandler(Object send, EventArgs args)
        {
            Calculator cal = send as Calculator;
            MyEventArgs mea = args as MyEventArgs;
            Console.WriteLine(cal.Plus(mea.i, mea.j));
        }
        public void OnEventHandler2(Object send, EventArgs args)
        {
            Calculator cal = send as Calculator;
            MyEventArgs mea = args as MyEventArgs;
            Console.WriteLine(cal.Plus(mea.j, 1000));
        }
    }
    class Calculator
    {
        public event EventHandler cb = null;    
        public int m_iData;
        public int data
        {
            get
            {
                return m_iData;
            }
            set
            {
                m_iData = value;
                if (cb != null)
                {
                    MyEventArgs e = new MyEventArgs(m_iData, m_iData);
                    cb(this, e);// EventArgs.Empty );
                }
            }
        }
       
        public int Plus(int a, int b) {
            return a + b;
        }
        public static int Minus(int a, int b) {
            return a - b;
        }
        public void Compute(EventHandler process)
        {
            process(this, EventArgs.Empty );
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Calculator Cals = new Calculator();
            EventHandler callback1 = 
                new EventHandler(new ProcessData().OnEventHandler );
            Cals.cb += callback1;
            Cals.data = 10;
        }
    }
}
