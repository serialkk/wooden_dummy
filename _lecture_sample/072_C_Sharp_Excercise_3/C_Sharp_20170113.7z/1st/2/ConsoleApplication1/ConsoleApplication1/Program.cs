﻿using System;
using ConsoleApplication1;
using System.Collections.Generic;
//namespace ConsoleApplication1
//{
class Program2
{
    int[] array = new int[] { 0, 1, 2, 3, 4, 5 };


    public int k = 100;
    //Class1 cls2 = new Class1();

    static void Main(string[] args)
    {
        int iValue = 3, jValue = 5;
        if( iValue == jValue)
        {
            Console.WriteLine("같다.");
        }
        int [] ar1 = {0,1,2,3 };
        int [] ar2 = ar1;
        if (ar1 == ar2)
        {
            Console.WriteLine("같다.");
        }
    }
}          
    
//}
