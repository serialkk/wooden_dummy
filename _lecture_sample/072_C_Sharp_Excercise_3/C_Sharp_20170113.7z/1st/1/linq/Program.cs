﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// language integrated query // sql
namespace linq
{
    class Program
    {
        public ArrayList Comute( int [] data)
        {
            ArrayList ar = new ArrayList();
            for( int i= 0; i < data.Length; i++)
            {
                if( data[i] %2 == 0 )
                {
                    //yield return data[i];
                    ar.Add(data[i]);
                }
            }
            return ar;
        }
        static void Main(string[] args)
        {
            int [] ar = new int[] {0,1,2,3,4,5,6 };
            
            //List<int> query =
            var query =
                (from int n in ar
                where (n % 2 == 0)
                select n).ToList();

            //IEnumerable<int> query2 =
            var query2 =
                from int n in ar
                where (n % 2 == 0)
                select n;
            List<int> ar2 = query2.ToList();

            foreach ( int k in query)
            {
                Console.Write( " " + k);
            }
            // from   절
            // where  절
            // select 절
        }
    }
}
