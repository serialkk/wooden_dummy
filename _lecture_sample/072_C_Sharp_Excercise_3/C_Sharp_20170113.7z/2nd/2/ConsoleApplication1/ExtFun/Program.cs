﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtFun
{
    class Integer
    {
        public int a;
        public Integer( int i) { a = i; }
        public int Add( int j) { return a + j; }     
    }
    static class IntegerExt  
    {
        public static int Mul( this Integer i,  int j)
        {
            return i.a*j;
        }
    }

    static  class intExt
    {
        public static int Power( this int a )
        {
            return a * a;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Integer num = new Integer(10);
            Console.WriteLine("{0}", num.Add(10));
            Console.WriteLine("{0}", num.Mul(10));
            Console.WriteLine("{0}", 3.Power());
        }
    }
}
