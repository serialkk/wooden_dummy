﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ExtFun
{
    class Integer
    {
        public int a;
        public Integer( int i) { a = i; }
        public int Add( int j) { return a + j; }     
    }
    static class IntegerExt  
    {
        public static int Mul( this Integer i,  int j)
        {
            return i.a*j;
        }
    }

    static  class intExt
    {
        public static int Power( this int a )
        {
            return a * a;
        }
    }
    class Program
    {
        static bool com( int k)
        {
            return k < 5;
        }
        static void Main(string[] args)
        {
            Expression<Func<int, bool>> expr = num => num < 5;
            Func<int, bool> result = expr.Compile();

            Console.WriteLine(result(10));




            // val = ( 1 * 2 ) + (x-y);            
            Expression const1 = Expression.Constant(1);
            Expression const2 = Expression.Constant(2);
            Expression left = Expression.Multiply( const1, const2 );
     
            Expression param1 = Expression.Parameter(typeof(int));
            Expression param2 = Expression.Parameter(typeof(int));
            Expression right = Expression.Subtract(param1, param2);

            Expression ext = Expression.Add(left, right);
            Expression<Func<int, int, int>> expression = 
             Expression<Func<int,int,int>>.Lambda<Func<int,int,int>>
                (
                    ext, new ParameterExpression[] {
                                (ParameterExpression)param1,
                                (ParameterExpression)param2   }
                  );
Func<int, int, int> func = expression.Compile();
            Console.WriteLine("{0}", func(10, 10));

            //Expression<Func<int, int, int>> expression2 =
            //               (a, b) => 1 * 2 + (a - b);
            //Func<int, int, int> func2 = expression2.Compile();
            //Console.WriteLine("{0}", func2(10,10));

            // Func <int, int, int> func2 = (a,b) => 1*2+ (a-b);





            //Integer num = new Integer(10);
            //Console.WriteLine("{0}", num.Add(10));
            //Console.WriteLine("{0}", num.Mul(10));
            //Console.WriteLine("{0}", 3.Power());
        }
    }
}
