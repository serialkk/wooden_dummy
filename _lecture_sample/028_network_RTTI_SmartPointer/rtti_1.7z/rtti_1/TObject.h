#pragma once
#include "stdafx.h"

class CObject
{
public:
	virtual CRuntimeClass* GetRuntimeClass() const { return NULL; }
	DECLARE_DYNAMIC(CObject);                                                        
	virtual ~CObject() {}
protected:
	CObject() {};
};
