#pragma once
#include "TObject.h"

class CAlpha : public CObject
{
public:
	virtual CRuntimeClass* GetRuntimeClass() const
	{
		return &classCAlpha;
	}
	DECLARE_DYNAMIC(CAlpha)                                    
	DECLARE_DYNCREATE(CAlpha)                              

protected:
	CAlpha() {};
};
                    