#include "stdafx.h"
#include "TAlpha.h"
IMPLEMENT_DYNAMIC(CAlpha)                                // CRuntimeClass CAlpha::classCAlpha= {"CAlpha", sizeof(CAlpha), CAlpha::CreateObject};
IMPLEMENT_DYNCREATE(CAlpha)