#include "stdafx.h"
#include "TObject.h"

CRuntimeClass CObject::classCObject = { "CObject", sizeof(CObject), NULL };
CObject* CRuntimeClass::CreateObject()
{
	return (*pfnCreateObject)();
}