// rtti_1.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.
//

#include "stdafx.h"
#include "TAlpha.h"
#include <memory>

struct TNode
{
	int k;
};
void  Print(TNode pNode)
{
	std::cout << pNode.k;
}
void  Print(TNode* pNode)
{
	std::cout << pNode->k;
}
void  Print( std::shared_ptr<TNode> pNode)
{
	std::cout << pNode->k;
}
int main()
{	
	TNode* pNode = new TNode;
	pNode->k = 100;
	delete pNode;

	std::shared_ptr<TNode> node2;
	node2 =  std::make_shared<TNode>();
	
	std::shared_ptr<TNode> node(new TNode());
	node->k = 200;
	Print(*node);
	Print(node.get());
	cout << node.get()->k;
	TNode* p = node.get();
	Print(node);

	auto SmartPrt = std::make_shared<TNode>();
	Print(SmartPrt);

	CRuntimeClass* pRTCAlpha = RUNTIME_CLASS(CAlpha);
	CObject* pObj = pRTCAlpha->CreateObject();
	cout << pObj->GetRuntimeClass()->m_lpszClassName << endl;
	delete pObj;	
    return 0;
}

