#include "Sample.h"
using namespace DX;



bool Sample::Init()
{
	
#pragma region g_pVertexShader
	m_Rect.g_pVertexShader =LoadVertexShaderFile(g_pd3dDevice,
			L"VertexShader.hlsl",
			&m_Rect.g_pVSBlob);
#pragma endregion
#pragma region g_pPixelShader
	m_Rect.g_pPixelShader = 
		DX::LoadPixelShaderFile(g_pd3dDevice,L"PixelShader.hlsl");
#pragma endregion
#pragma region g_pInputlayout
	D3D11_INPUT_ELEMENT_DESC layout[] =
	{
		{ "POSITION",0,DXGI_FORMAT_R32G32B32_FLOAT,0,0,D3D11_INPUT_PER_VERTEX_DATA,0 },
		{ "COLOR",0,DXGI_FORMAT_R32G32B32A32_FLOAT,0,12,D3D11_INPUT_PER_VERTEX_DATA,0 },
	};
	UINT numElements =	sizeof(layout) / sizeof(layout[0]);
	m_Rect.g_pInputlayout = 	CreateInputlayout(g_pd3dDevice,
			layout, numElements,
			m_Rect.g_pVSBlob);
#pragma endregion
#pragma region g_pVertexBuffer
	vertices[0].Pos = TVector3(-0.5f, 0.5f, 0.0f);
	vertices[0].Color0 = TVector4(1.0f, 0.0f, 0.0f, 1.0f);
	vertices[1].Pos = TVector3( 0.5f, 0.5f, 0.0f);
	vertices[1].Color0 = TVector4(1.0f, 0.0f, 0.0f, 1.0f);
	vertices[2].Pos = TVector3(0.5f, -0.5f, 0.0f);
	vertices[2].Color0 = TVector4(1.0f, 0.0f, 0.0f, 1.0f);
	vertices[3].Pos = TVector3(-0.5f, -0.5f, 0.0f);
	vertices[3].Color0 = TVector4(1.0f, 0.0f, 0.0f, 1.0f);

	int iNumVertex = sizeof(vertices) / sizeof(vertices[0]);
	m_Rect.g_pVertexBuffer = 
		DX::CreateBuffer(g_pd3dDevice, vertices,
		iNumVertex, sizeof(SimpleVertex),
			D3D11_BIND_VERTEX_BUFFER);
#pragma endregion
#pragma region g_pIndexBuffer
	DWORD indices[] ={	0,1,2,0,2,3,	};
	int iNumIndex = sizeof(indices) / sizeof(indices[0]);
	m_Rect.g_pIndexBuffer = 
		CreateBuffer(g_pd3dDevice, indices,
		iNumIndex, sizeof(DWORD),
			D3D11_BIND_INDEX_BUFFER);
#pragma endregion
#pragma region g_pConstantBuffer
	m_Rect.g_pConstantBuffer = 
		CreateBuffer(g_pd3dDevice, &m_cb,
		1, sizeof(VS_CONSTANT_BUFFER),
			D3D11_BIND_CONSTANT_BUFFER,
			true);
#pragma endregion
	return true;
}
bool Sample::Frame()
{
	D3D11_MAPPED_SUBRESOURCE mr;
	if (SUCCEEDED(g_pImmediateContext->Map(
		m_Rect.g_pConstantBuffer, 0,
		D3D11_MAP_WRITE_DISCARD, 0, &mr)))
	{
		VS_CONSTANT_BUFFER* pData = (VS_CONSTANT_BUFFER*)mr.pData;

		pData->vColor = TVector4(cosf(m_Timer.m_fAccumulation),
			sinf(m_Timer.m_fAccumulation), 0, 1);
		pData->fTime = (cosf(m_Timer.m_fAccumulation)+1.0f )/ 2.0f;
		g_pImmediateContext->Unmap(m_Rect.g_pConstantBuffer, 0);		
	}
	
	m_cb.vColor = TVector4(1,0,0,1);
	m_cb.fTime = cosf(m_Timer.m_fAccumulation);

	vertices[0].Pos = TVector3(-0.5f, 0.5f, 0.0f)*m_cb.fTime;
	vertices[0].Color0 = TVector4(1.0f, 0.0f, 0.0f, 1.0f);
	vertices[1].Pos = TVector3( 0.5f, 0.5f, 0.0f)*m_cb.fTime;
	vertices[1].Color0 = TVector4(1.0f, 0.0f, 0.0f, 1.0f);
	vertices[2].Pos = TVector3(0.5f, -0.5f, 0.0f)*m_cb.fTime;
	vertices[2].Color0 = TVector4(1.0f, 0.0f, 0.0f, 1.0f);
	vertices[3].Pos = TVector3(-0.5f, -0.5f, 0.0f)*m_cb.fTime;
	vertices[3].Color0 = TVector4(1.0f, 0.0f, 0.0f, 1.0f);

	g_pImmediateContext->UpdateSubresource(
		m_Rect.g_pVertexBuffer,
		0, NULL, &vertices, 0, 0);
	return m_Rect.Frame();
}
bool Sample::Render()
{	
	m_Rect.Render(g_pImmediateContext,sizeof(SimpleVertex),6);	
	return true;
}
bool Sample::Release()
{	

	return true;
}
Sample::Sample()
{
}


Sample::~Sample()
{
}

TCORE_RUN(_T("Sample Win"), 800, 600)