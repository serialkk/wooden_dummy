#include "Sample.h"



Sample::Sample()
{
}


Sample::~Sample()
{
}
