#include "Sample.h"
ID3D11Texture2D* Sample::GetTexture2DFromFile(
	LPCWSTR filename,
	D3DX11_IMAGE_LOAD_INFO* pLoadInfo)
{
	ID3D11Texture2D* texture = NULL;
	ID3D11Resource*  pRes = NULL;

	HRESULT hr = D3DX11CreateTextureFromFile(
		m_pd3dDevice, 
		filename, 
		pLoadInfo,
		NULL, 
		&pRes, 
		NULL);
	if (FAILED(hr))
	{
		H(hr);
		return NULL;
	}
	pRes->QueryInterface(__uuidof(ID3D11Texture2D), (LPVOID*)&texture);
	pRes->Release();
	return texture;
}
void Sample::WriteDotPixel(ID3D11Texture2D* pTex)
{
	D3D11_TEXTURE2D_DESC td;
	pTex->GetDesc(&td);
	D3D11_MAPPED_SUBRESOURCE map;
	if (SUCCEEDED(GetContext()->Map(
		(ID3D11Resource*)pTex, 0, D3D11_MAP_READ_WRITE,
		0, &map)))
	{
		BYTE* pData = (BYTE*)map.pData;
		for (UINT y = 0; y < td.Height; y++)
		{
			for (UINT x = 0; x < td.Width; x++)
			{
				BYTE r, g, b, a;
				r = pData[0];
				g = pData[1];
				b = pData[2];
				a = pData[3];	
				if (r <= 100 && g <= 100 && b <= 100)
				{
					*pData++ = 255;
					*pData++ = 0;
					*pData++ = 0;
					*pData++ = 255;
				}
				else
				{
					pData += 4;
				}
			}
			//pData += map.RowPitch;
		}
		GetContext()->Unmap(pTex, 0);
	}
}
bool Sample::Init()
{
	g_pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D),
		(LPVOID*)&m_pBackBufferTex);

	g_pSwapChain->GetDesc(&m_sd);
	D3DX11_IMAGE_LOAD_INFO loadInfo;
	ZeroMemory(&loadInfo, sizeof(D3DX11_IMAGE_LOAD_INFO));
	loadInfo.Width = m_sd.BufferDesc.Width;
	loadInfo.Height = m_sd.BufferDesc.Height;
	loadInfo.Depth = D3DX11_DEFAULT;
	loadInfo.FirstMipLevel = 0;
	loadInfo.MipLevels = 1;	// �ݵ�� 1 �̿��� �Ѵ�.
	loadInfo.Usage = D3D11_USAGE_STAGING;    
	loadInfo.CpuAccessFlags = D3D11_CPU_ACCESS_WRITE | D3D11_CPU_ACCESS_READ;
	loadInfo.BindFlags = 0;
	loadInfo.MiscFlags = 0;
	loadInfo.Format = m_sd.BufferDesc.Format;
	loadInfo.Filter = D3DX11_FILTER_LINEAR;
	loadInfo.MipFilter = D3DX11_FILTER_NONE;
	m_Texture1 = GetTexture2DFromFile(
		L"02.jpg",
		&loadInfo);
	m_Texture1->GetDesc(&m_td1);	
	WriteDotPixel(m_Texture1);

	loadInfo.Width  = 200;// m_sd.BufferDesc.Width;
	loadInfo.Height = 200;// m_sd.BufferDesc.Height;	
	m_Texture2 = GetTexture2DFromFile(
		L"checker_with_numbers.bmp",
		&loadInfo);
	m_Texture2->GetDesc(&m_td2);
	return true;
}
bool Sample::Render()
{
	// ��ü ����(�ݵ�� ��ġ �ؾ� �Ѵ�.)
	GetContext()->CopyResource(	m_pBackBufferTex,	m_Texture1);

	D3D11_BOX Region;
	Region.left = 0;
	Region.right = m_td2.Width / 2;
	Region.top = m_td2.Height / 2;
	Region.bottom = m_td2.Height;
	Region.front = 0;
	Region.back = 1;
	GetContext()->CopySubresourceRegion(
		m_pBackBufferTex, 0, 200+cosf(m_Timer.m_fAccumulation)*100, 0, 0,
		m_Texture2, 0, &Region);

	static bool bSave = false;
	Sleep(1000);
	if (bSave == false)
	{
		D3DX11SaveTextureToFile(GetContext(), m_pBackBufferTex,
			D3DX11_IFF_PNG, L"kgca.png");
		bSave = true;
	}
	return true;
}
bool Sample::Release()
{		
	if (m_Texture1)m_Texture1->Release();
	if (m_Texture2)m_Texture2->Release();
	if (m_pBackBufferTex)m_pBackBufferTex->Release();
	return true;
}
Sample::Sample()
{
	m_Texture2 = m_Texture1 = NULL;
}


Sample::~Sample()
{
}

TCORE_RUN(_T("Sample Win"), 800, 600)