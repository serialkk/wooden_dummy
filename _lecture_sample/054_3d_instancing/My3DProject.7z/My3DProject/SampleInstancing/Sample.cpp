#include "Sample.h"

bool	Sample::Init()
{
	UINT iIndex = I_SpriteMgr.Add(L"blend.hlsl",
		L"../../data/pung_yellow.dds",
		TDxState::g_pAddBlend);
	m_pSprite = I_SpriteMgr.GetPtr(iIndex);
	m_pSprite->SetAttribute(30.0f, 16.0f, 4, 4);
	
	for (int iSt = 0; iSt < 10; iSt++)
	{
		D3DXMatrixIdentity(
			&m_pSprite->m_pInstance[iSt].matWorld);
		m_pSprite->m_pInstance[iSt].matWorld._41 = iSt;

		m_pSprite->m_pInstance[iSt].uv[0] = D3DXVECTOR4(0, 0,0,0);
		m_pSprite->m_pInstance[iSt].uv[1] = D3DXVECTOR4(0.25f, 0, 0, 0);
		m_pSprite->m_pInstance[iSt].uv[2] = D3DXVECTOR4(0.25f, 0.25f, 0, 0);
		m_pSprite->m_pInstance[iSt].uv[3] = D3DXVECTOR4(0, 0.25f, 0, 0);

		m_pSprite->m_pInstance[iSt].color = 
			D3DXVECTOR4((rand() & RAND_MAX) / (float)RAND_MAX,
			(rand() & RAND_MAX) / (float)RAND_MAX,
			(rand() & RAND_MAX) / (float)RAND_MAX,
			1);
		D3DXMatrixTranspose(
			&m_pSprite->m_pInstance[iSt].matWorld, 
			&m_pSprite->m_pInstance[iSt].matWorld);
	}

	m_pVBInstance.Attach(
		DX::CreateBuffer(g_pd3dDevice,
			&m_pSprite->m_pInstance,
			10,
			sizeof(TInstatnce),
			D3D11_BIND_VERTEX_BUFFER));

	/*m_pVertexShader.Attach(
		LoadVertexShaderFile(m_pd3dDevice,
			L"Blend.hlsl",
			m_pVSBlob.GetAddressOf()));*/


	D3D11_INPUT_ELEMENT_DESC layout[] =
	{
		{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0,  0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "COLOR",    0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 12, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT,    0, 28, D3D11_INPUT_PER_VERTEX_DATA, 0 },

		{ "TRANSFORM", 0, DXGI_FORMAT_R32G32B32A32_FLOAT,    1, 0, D3D11_INPUT_PER_INSTANCE_DATA, 1 },
		{ "TRANSFORM", 1, DXGI_FORMAT_R32G32B32A32_FLOAT,    1, 16, D3D11_INPUT_PER_INSTANCE_DATA, 1 },
		{ "TRANSFORM", 2, DXGI_FORMAT_R32G32B32A32_FLOAT,    1, 32, D3D11_INPUT_PER_INSTANCE_DATA, 1 },
		{ "TRANSFORM", 3, DXGI_FORMAT_R32G32B32A32_FLOAT,    1, 48, D3D11_INPUT_PER_INSTANCE_DATA, 1 },

		{ "ANIMATION", 0, DXGI_FORMAT_R32G32B32A32_FLOAT,    1, 64, D3D11_INPUT_PER_INSTANCE_DATA, 1 },
		{ "ANIMATION", 1, DXGI_FORMAT_R32G32B32A32_FLOAT,    1, 80, D3D11_INPUT_PER_INSTANCE_DATA, 1 },
		{ "ANIMATION", 2, DXGI_FORMAT_R32G32B32A32_FLOAT,    1, 96, D3D11_INPUT_PER_INSTANCE_DATA, 1 },
		{ "ANIMATION", 3, DXGI_FORMAT_R32G32B32A32_FLOAT,    1, 112, D3D11_INPUT_PER_INSTANCE_DATA, 1 },

		{ "MESHCOLOR", 0, DXGI_FORMAT_R32G32B32A32_FLOAT,    1, 128, D3D11_INPUT_PER_INSTANCE_DATA, 1 },

	};
	UINT numElements = sizeof(layout) / sizeof(layout[0]);
	m_pInputlayout.Attach(
		CreateInputlayout(g_pd3dDevice,
			layout, numElements,
			m_pSprite->m_Object.g_pVSBlob.Get()));

	m_Camera.Create(m_pd3dDevice);
	D3DXMatrixIdentity(&m_matWorld);
	return true;
}
bool	Sample::Frame()
{
	m_Camera.Update(D3DXVECTOR4(0, 0, 0, 0));
	m_pSprite->Frame();
	return true;
}

bool	Sample::Render()
{
	m_pSprite->SetMatrix(
		&m_matWorld, 
		&m_Camera.m_matView,
		&m_Camera.m_matProj);
	m_pSprite->PreDraw(g_pImmediateContext, m_pSprite->m_iApplyIndex);
	{
		g_pImmediateContext->IASetInputLayout(m_pInputlayout.Get());
		
		ID3D11Buffer* vb[2] = { 
			m_pSprite->m_Object.g_pVertexBuffer.Get(),
			m_pVBInstance.Get()};

		UINT stride[2] = {sizeof(PCT_VERTEX), sizeof(TInstatnce)};
		UINT offset[2] = { 0, 0 };
		g_pImmediateContext->IASetVertexBuffers(
			0, 2, vb, stride, offset);

		g_pImmediateContext->UpdateSubresource(
			m_pSprite->m_Object.g_pConstantBuffer.Get(), 0, NULL,
			&m_pSprite->m_cbData, 0, 0);
	}
	g_pImmediateContext->DrawIndexedInstanced(
		6, 10, 0, 0, 0);
	return true;
}
bool	Sample::Release() {
	return true;
}

Sample::Sample()
{

}


Sample::~Sample()
{
}
TCORE_RUN(_T("Sample Lib"), 800, 600)