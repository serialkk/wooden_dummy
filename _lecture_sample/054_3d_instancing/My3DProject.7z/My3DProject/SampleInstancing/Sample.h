#pragma once
#include "Tcore.h"
#include "TShape.h"
#include "TCamera.h"
#include <memory>
#include "TSpriteMgr.h"
#define MAX_CNT 10

class Sample : public TCore
{
public:
	TSprite*   m_pSprite;
	ComPtr<ID3D11Buffer>		m_pVBInstance;
	ComPtr<ID3D11VertexShader>  m_pVertexShader;
	ComPtr<ID3DBlob>			m_pVSBlob;
	ComPtr<ID3D11InputLayout>   m_pInputlayout;
	TCamera		m_Camera;
	D3DXMATRIX m_matWorld;
public:
	bool	Init();
	bool	Frame();
	bool	Render();
	bool	Release();
	Sample();
	virtual ~Sample();
};

