#include "TVector.h"
// 2
float		TVector2::Length()
{
	return (float)sqrt(x*x + y*y);
}
TVector2    TVector2::Normal()
{
	float InvertLength = 1.0f / Length();
	return TVector2(x*InvertLength, y*InvertLength);
}
TVector2    TVector2::operator + (TVector2 &v0)
{
	return TVector2(x + v0.x, y + v0.y);
}
TVector2    TVector2::operator - (TVector2 &v0)
{
	return TVector2(x - v0.x, y - v0.y);
}
TVector2    TVector2::operator * (float &fScale)
{
	return TVector2(x * fScale, y * fScale);
}

bool    TVector2::operator == (TVector2 & v0)
{
	if (fabs(x - v0.x) < 0.0001f)
	{
		if (fabs(y - v0.y) < 0.0001f)
		{

			return true;

		}
	}
	return false;
}
TVector2::TVector2(float fX, float fY)
{
	x = fX;
	y = fY;
}
TVector2::TVector2()
{
	x = y = 0;
}
TVector2::TVector2(const TVector2& v0)
{
	x = v0.x;
	y = v0.y;
}

TVector2::~TVector2()
{
}
// 3
float		TVector3::Length()
{
	return (float)sqrt(x*x + y*y + z*z);
}
TVector3    TVector3::Normal()
{
	float InvertLength = 1.0f / Length();
	return TVector3(x*InvertLength, y*InvertLength, z*InvertLength);
}
TVector3    TVector3::operator + (TVector3 &v0)
{
	return TVector3(x + v0.x, y + v0.y, z + v0.z);
}
TVector3    TVector3::operator - (TVector3 &v0)
{
	return TVector3(x - v0.x, y - v0.y, z - v0.z);
}
TVector3    TVector3::operator * (float &fScale)
{
	return TVector3(x * fScale, y * fScale, z * fScale);
}
float	    TVector3::operator | (TVector3 const& v0)
{
	return x * v0.x + y * v0.y + z * v0.z;
}
// TVector3 = a ^ b
TVector3	    TVector3::operator ^ (TVector3 const& v0)
{
	return TVector3(( y*v0.z - z * v0.y), 
					(z * v0.x - x *  v0.z) ,
					(x * v0.y -  y * v0.x));
}
bool    TVector3::operator == (TVector3 & v0)
{
	if (fabs(x - v0.x) < 0.0001f)
	{
		if (fabs(y - v0.y) < 0.0001f)
		{
			if (fabs(z - v0.z) < 0.0001f)
			{
				return true;
			}
		}
	}
	return false;
}
float  TVector3::Angle(TVector3& v0)
{
	float fAngle;
	TVector3 a = Normal();
	TVector3 b = v0.Normal();
	float fCosDot = a | b;
	fAngle = acos(fCosDot);
	fAngle = fAngle * ( 180.0f / 3.141592f);
	return fAngle;
}
TVector3::TVector3(float fX, float fY, float fZ)
{
	x = fX;
	y = fY;
	z = fZ;
}
TVector3::TVector3()
{
	x = y = z = 0;
}
TVector3::TVector3(const TVector3& v0)
{
	x = v0.x;
	y = v0.y;
	z = v0.z;
}

TVector3::~TVector3()
{
}
//4
float		TVector4::Length()
{
	return (float)sqrt(x*x + y*y + z*z + w*w);
}
TVector4    TVector4::Normal()
{
	float InvertLength = 1.0f / Length();
	return TVector4(x*InvertLength,
		y*InvertLength, z*InvertLength
		, w*InvertLength);
}
TVector4    TVector4::operator + (TVector4 &v0)
{
	return TVector4(x + v0.x, y + v0.y, z + v0.z
		, w + v0.w);
}
TVector4    TVector4::operator - (TVector4 &v0)
{
	return TVector4(x - v0.x, y - v0.y, z - v0.z
		, w - v0.w);
}
TVector4    TVector4::operator * (float &fScale)
{
	return TVector4(x * fScale, y * fScale,
		z * fScale, w * fScale);
}
bool    TVector4::operator == (TVector4 & v0)
{
	if (fabs(x - v0.x) < 0.0001f)
	{
		if (fabs(y - v0.y) < 0.0001f)
		{
			if (fabs(z - v0.z) < 0.0001f)
			{
				if (fabs(w - v0.w) < 0.0001f)
				{
					return true;
				}
			}
		}
	}
	return false;
}
TVector4::TVector4(float fX, float fY,
	float fZ, float fW)
{
	x = fX;
	y = fY;
	z = fZ;
	w = fW;
}
TVector4::TVector4()
{
	x = y = z = w = 0;
}
TVector4::TVector4(const TVector4& v0)
{
	x = v0.x;
	y = v0.y;
	z = v0.z;
	w = v0.w;
}

TVector4::~TVector4()
{
}
