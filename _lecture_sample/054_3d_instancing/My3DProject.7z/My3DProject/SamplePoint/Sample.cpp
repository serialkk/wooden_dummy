#include "Sample.h"
#include <time.h>
#include "TVector.h"
bool	Sample::Init()
{
	HRESULT hr;

	TVector3 a(0,0,1);
	TVector3 b(1,0,0);

	float fDot = a | b;
	TVector3 c = (a ^ b).Normal();

	float fAngle = a.Angle(b);

	if (FAILED(hr = D3DX11CreateShaderResourceViewFromFile(
		g_pd3dDevice,
		L"../../data/checker_with_numbers.bmp",
		NULL, NULL, &m_pTexSRV,
		NULL)))
	{
		H(hr);
		return false;
	}

	D3D11_SHADER_RESOURCE_VIEW_DESC srvd;
	m_pTexSRV->GetDesc(&srvd);
	int iMaxLod = srvd.Texture2D.MipLevels;

	if (m_pSamplerState)m_pSamplerState->Release();
	D3D11_SAMPLER_DESC sd;
	ZeroMemory(&sd, sizeof(D3D11_SAMPLER_DESC));
	sd.Filter = D3D11_FILTER_ANISOTROPIC;
	sd.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
	sd.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
	sd.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
	sd.BorderColor[0] = 0.0f;
	sd.BorderColor[1] = 0.0f;
	sd.BorderColor[2] = 0.0f;
	sd.BorderColor[3] = 1.0f;
	sd.MaxAnisotropy = 16;
	sd.MinLOD = 0;
	sd.MaxLOD = 0;
	if (FAILED(hr = g_pd3dDevice->CreateSamplerState(&sd, &m_pSamplerState)))
	{
		H(hr);
		return false;
	}

#pragma region g_pVertexShader
	m_Object.g_pVertexShader = 
		LoadVertexShaderFile(g_pd3dDevice,
		L"Shader.hlsl",
		&m_Object.g_pVSBlob);
#pragma endregion
#pragma region g_pPixelShader
	m_Object.g_pPixelShader =
		DX::LoadPixelShaderFile(g_pd3dDevice, L"Shader.hlsl");
#pragma endregion
#pragma region g_pGeometryShader
	m_Object.g_pGeometryShader =
		DX::LoadGeometryShaderFile(g_pd3dDevice, L"Shader.hlsl");
#pragma endregion
#pragma region g_pInputlayout
	D3D11_INPUT_ELEMENT_DESC layout[] =
	{
		{ "POSITION",0,DXGI_FORMAT_R32G32B32_FLOAT,0,0,D3D11_INPUT_PER_VERTEX_DATA,0 },
		{ "COLOR",0,DXGI_FORMAT_R32G32B32A32_FLOAT,0,12,D3D11_INPUT_PER_VERTEX_DATA,0 },
	};
	UINT numElements = sizeof(layout) / sizeof(layout[0]);
	m_Object.g_pInputlayout = CreateInputlayout(g_pd3dDevice,
		layout, numElements,
		m_Object.g_pVSBlob);
#pragma endregion
#pragma region g_pVertexBuffer

	srand(time(NULL));
	SimpleVertex vertices[MAX_VERTEX];
	for (int iVer = 0; iVer < MAX_VERTEX; iVer++)
	{
		vertices[iVer].x = randstep(-0.5f, 0.5f);
		vertices[iVer].y = randstep(-0.5f, 0.5f);
		vertices[iVer].z = 0.0f;
		vertices[iVer].r = randstep(0.0f, 1.0f);
		vertices[iVer].g = randstep(0.0f, 1.0f);
		vertices[iVer].b = randstep(0.0f, 1.0f);
		vertices[iVer].a = 1.0f;
	}	
	int iNumVertex = sizeof(vertices) / sizeof(vertices[0]);
	m_Object.g_pVertexBuffer =
		DX::CreateBuffer(g_pd3dDevice, vertices,
			iNumVertex, sizeof(SimpleVertex),
			D3D11_BIND_VERTEX_BUFFER);
#pragma endregion
#pragma region g_pIndexBuffer
	DWORD indices[] = { 0,1,2, 0,2,3,};
	int iNumIndex = sizeof(indices) / sizeof(indices[0]);
	m_Object.g_pIndexBuffer =
		CreateBuffer(g_pd3dDevice, indices,
			iNumIndex, sizeof(DWORD),
			D3D11_BIND_INDEX_BUFFER);
#pragma endregion
#pragma region g_pConstantBuffer
	m_cbData.x0 = randstep(0.0f, 1.0f);
	m_cbData.y0 = randstep(0.0f, 1.0f);
	m_cbData.z0 = randstep(0.0f, 1.0f);
	m_cbData.z0 = 1.0f;

	m_cbData.x1 = randstep(0.0f, 1.0f);
	m_cbData.y1 = randstep(0.0f, 1.0f);
	m_cbData.z1 = randstep(0.0f, 1.0f);
	m_cbData.z1 = 1.0f;

	m_cbData.x2 = randstep(0.0f, 1.0f);
	m_cbData.y2 = randstep(0.0f, 1.0f);
	m_cbData.z2 = randstep(0.0f, 1.0f);
	m_cbData.z2 = 1.0f;

	m_cbData.x3 = randstep(0.0f, 1.0f);
	m_cbData.y3 = randstep(0.0f, 1.0f);
	m_cbData.z3 = randstep(0.0f, 1.0f);
	m_cbData.z3 = 1.0f;
	m_cbData.time = 1.0f;
	m_Object.g_pConstantBuffer =
		CreateBuffer(g_pd3dDevice, &m_cbData,
			1, sizeof(VS_CONSTANT_BUFFER),
			D3D11_BIND_CONSTANT_BUFFER,
			false);
#pragma endregion

	return true;
}
bool	Sample::Frame() {
	static float ftime = 0.0f;
	static int iIndex = 0;
	ftime += g_fSecPerFrame;
	
	if (ftime > 1.0f)
	{				
		m_cbData.x0 = randstep(0.0f, 1.0f);
		m_cbData.y0 = randstep(0.0f, 1.0f);
		m_cbData.z0 = randstep(0.0f, 1.0f);
		m_cbData.z0 = 1.0f;
		
		m_cbData.x1 = randstep(0.0f, 1.0f);
		m_cbData.y1 = randstep(0.0f, 1.0f);
		m_cbData.z1 = randstep(0.0f, 1.0f);
		m_cbData.z1 = 1.0f;
	
		m_cbData.x2 = randstep(0.0f, 1.0f);
		m_cbData.y2 = randstep(0.0f, 1.0f);
		m_cbData.z2 = randstep(0.0f, 1.0f);
		m_cbData.z2 = 1.0f;
		
		m_cbData.x3 = randstep(0.0f, 1.0f);
		m_cbData.y3 = randstep(0.0f, 1.0f);
		m_cbData.z3 = randstep(0.0f, 1.0f);
		m_cbData.z3 = 1.0f;
		ftime = 0.0f;
	}
	m_cbData.time = cosf(m_Timer.m_fAccumulation)*0.5f+0.5f;
	m_cbData.time *= 0.5f;
	return m_Object.Frame();
}
bool	Sample::Render() {

	D3D11_VIEWPORT vp[4];
	vp[0].Width = (FLOAT)m_dwWidth/2;
	vp[0].Height = (FLOAT)m_dwHeight/2;
	vp[0].MinDepth = 0.0f;
	vp[0].MaxDepth = 1.0f;
	vp[0].TopLeftX = 0;
	vp[0].TopLeftY = 0;
	vp[1].Width = (FLOAT)m_dwWidth / 2;
	vp[1].Height = (FLOAT)m_dwHeight / 2;
	vp[1].MinDepth = 0.0f;
	vp[1].MaxDepth = 1.0f;
	vp[1].TopLeftX = m_dwWidth / 2;
	vp[1].TopLeftY = 0;
	
	vp[3].Width = (FLOAT)m_dwWidth / 2;
	vp[3].Height = (FLOAT)m_dwHeight / 2;
	vp[3].MinDepth = 0.0f;
	vp[3].MaxDepth = 1.0f;
	vp[3].TopLeftX = 0;
	vp[3].TopLeftY = m_dwHeight / 2;

	vp[2].Width = (FLOAT)m_dwWidth / 2;
	vp[2].Height = (FLOAT)m_dwHeight / 2;
	vp[2].MinDepth = 0.0f;
	vp[2].MaxDepth = 1.0f;
	vp[2].TopLeftX = m_dwWidth / 2;
	vp[2].TopLeftY = m_dwHeight / 2;

	g_pImmediateContext->RSSetViewports(
		4, vp);

	for (int iVp = 0; iVp < 4; iVp++)
	{	
		m_cbData.vp = iVp;
		g_pImmediateContext->UpdateSubresource(m_Object.g_pConstantBuffer, 0, NULL, &m_cbData, 0, 0);
		ApplyRS(g_pImmediateContext, TDxState::g_pCullSolidRS[m_Object.m_iCullMode]);
		if (m_Object.m_bWireFrameRender)
		{
			ApplyRS(g_pImmediateContext, TDxState::g_pWireFrameRS);
		}
		// ������Ƽ��� ������ƼŬ�� ����ϱ� ������ �����Ǿ� �Ѵ�.
		g_pImmediateContext->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_POINTLIST);
		g_pImmediateContext->IASetInputLayout(m_Object.g_pInputlayout);
		UINT stride = sizeof(SimpleVertex);
		UINT offset = 0;
		g_pImmediateContext->IASetVertexBuffers(0, 1, &m_Object.g_pVertexBuffer, &stride, &offset);
		g_pImmediateContext->IASetIndexBuffer(m_Object.g_pIndexBuffer, DXGI_FORMAT_R32_UINT, 0);
		/*g_pImmediateContext->IASetIndexBuffer(NULL, DXGI_FORMAT_R32_UINT, 0);*/
		g_pImmediateContext->VSSetConstantBuffers(0, 1, &m_Object.g_pConstantBuffer);
		g_pImmediateContext->VSSetShader(m_Object.g_pVertexShader, NULL, 0);
		g_pImmediateContext->GSSetConstantBuffers(0, 1, &m_Object.g_pConstantBuffer);
		g_pImmediateContext->GSSetShader(m_Object.g_pGeometryShader, NULL, 0);
		g_pImmediateContext->PSSetShader(m_Object.g_pPixelShader, NULL, 0);
		g_pImmediateContext->PSSetShaderResources(0, 1, &m_pTexSRV);
		g_pImmediateContext->PSSetSamplers(0, 1, &m_pSamplerState);
		g_pImmediateContext->Draw(MAX_VERTEX, 0);
		/*static float time = 0.0f;
		static int iIndex = 0;
		time += g_fSecPerFrame;
		if (time > 1.0f / MAX_VERTEX)
		{
			iIndex++;
			if (iIndex >= MAX_VERTEX)
			{
				iIndex = 1;
			}
			time -= 1.0f / MAX_VERTEX;
		}
		g_pImmediateContext->Draw(MAX_VERTEX - iIndex, iIndex - 1);
		*///g_pImmediateContext->DrawIndexed(6, 0, 0);
	}
	return true;
}
bool	Sample::Release() {
	if (m_pTexSRV) m_pTexSRV->Release();
	if (m_pSamplerState) m_pSamplerState->Release();
	m_Object.Release();
	return true;
}

Sample::Sample()
{
	m_cbData.r = 1.0f;
	m_cbData.g = 0.0f;
	m_cbData.b = 0.0f;
	m_cbData.a = 1.0f;
}


Sample::~Sample()
{
}
TCORE_RUN(_T("Sample Lib"), 800, 600)