#pragma once
#include "Tcore.h"

struct SimpleVertex
{
	float x, y, z;
	float r,g,b,a;
};
struct VS_CONSTANT_BUFFER
{	
	float r, g, b, a;
	float x0, y0, z0, w0;
	float x1, y1, z1, w1;
	float x2, y2, z2, w2;
	float x3, y3, z3, w3;
	float time, vp, z, w;
};
#define MAX_VERTEX 10
class Sample : public TCore
{
public:
	TDXObject			m_Object;
	VS_CONSTANT_BUFFER	m_cbData;
	ID3D11ShaderResourceView*   m_pTexSRV;
	ID3D11SamplerState*			m_pSamplerState;
public:
	bool	Init();
	bool	Frame();
	bool	Render();
	bool	Release();
	Sample();
	virtual ~Sample();
};

