#pragma once
#include "Tcore.h"
using namespace DX;

struct SimpleVertex
{
	D3DXVECTOR3 p;
	D3DXVECTOR4 c;	
};
struct VS_CONSTANT_BUFFER
{
	D3DXMATRIX matWorld;
	D3DXMATRIX matView;
	D3DXMATRIX matProj;
	float time, vp, z, w;
};
#define MAX_VERTEX 4
class Sample : public TCore
{
public:
	TDXObject			m_Object;
	VS_CONSTANT_BUFFER	m_cbData;
	ID3D11ShaderResourceView*   m_pTexSRV[4];
	ID3D11SamplerState*			m_pSamplerState;
	D3DXMATRIX m_matWorld[MAX_VERTEX];
	D3DXMATRIX m_matView;
	D3DXMATRIX m_matProj;
	D3DXVECTOR3 m_vEye;	
public:
	bool	Init();
	bool	Frame();
	bool	Render();
	bool	Release();
	Sample();
	virtual ~Sample();
};

