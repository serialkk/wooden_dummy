#include "Sample.h"
#include <time.h>

HRESULT Sample::CreateBlendState()
{
	HRESULT hr=S_OK;
	D3D11_BLEND_DESC bd;
	ZeroMemory(&bd, sizeof(bd));

	bd.RenderTarget[0].BlendEnable = TRUE;
	// final color = srccolor* srcblend - deskcolor * destblend 
	bd.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
	bd.RenderTarget[0].DestBlend = D3D11_BLEND_ONE;
	bd.RenderTarget[0].SrcBlend = D3D11_BLEND_ZERO;

	// finla alpah
	bd.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
	bd.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ONE;
	bd.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;

	bd.RenderTarget[0].RenderTargetWriteMask = 
		D3D11_COLOR_WRITE_ENABLE_ALL;
	hr = g_pd3dDevice->CreateBlendState(&bd, m_pNoSrcBlendState.GetAddressOf());

	bd.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
	bd.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
	bd.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
	hr = g_pd3dDevice->CreateBlendState(&bd, m_pSrcBlendState.GetAddressOf());

	return hr;
}
HRESULT Sample::CreateDSS()
{
	HRESULT hr;
	D3D11_DEPTH_STENCIL_DESC dsd;
	ZeroMemory(&dsd, sizeof(dsd));
	dsd.DepthEnable = TRUE;
	dsd.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
	dsd.DepthFunc = D3D11_COMPARISON_LESS_EQUAL;

	dsd.StencilEnable = TRUE;
	dsd.StencilReadMask = 0xffffffff;
	dsd.StencilWriteMask = 0xffffffff;

	dsd.FrontFace.StencilFunc = D3D11_COMPARISON_NOT_EQUAL;
	// ���ٽ� ������ ���� ���� ����� ó��
	dsd.FrontFace.StencilFailOp = D3D11_STENCIL_OP_KEEP;
	// ���� ������  ���� ���� ����� ó��
	dsd.FrontFace.StencilDepthFailOp = D3D11_STENCIL_OP_KEEP;
	// ���ٽ� ������ ���� ���� ���
	dsd.FrontFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;

	dsd.BackFace.StencilFunc = D3D11_COMPARISON_NOT_EQUAL;
	// ���ٽ� ������ ���� ���� ����� ó��
	dsd.BackFace.StencilFailOp = D3D11_STENCIL_OP_KEEP;
	// ���� ������  ���� ���� ����� ó��
	dsd.BackFace.StencilDepthFailOp = D3D11_STENCIL_OP_KEEP;
	// ���ٽ� ������ ���� ���� ���
	dsd.BackFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;

	if (FAILED(hr = m_pd3dDevice->CreateDepthStencilState(
		&dsd, &m_pNotEqualDSS)))
	{
		return hr;
	}
	dsd.DepthEnable = TRUE;
	dsd.StencilEnable = FALSE;
	if (FAILED(hr = m_pd3dDevice->CreateDepthStencilState(
		&dsd, &m_pNoStencilDSS)))
	{
		return hr;
	}
	return hr;
}
bool	Sample::Init()
{
	HRESULT hr;
	CreateBlendState();
	CreateDSS();

	if (FAILED(hr = D3DX11CreateShaderResourceViewFromFile(
		g_pd3dDevice,
		L"../../data/shine0.bmp",
		NULL, NULL, &m_pTexSRV[0],
		NULL)))
	{
		H(hr);
		return false;
	}
	if (FAILED(hr = D3DX11CreateShaderResourceViewFromFile(
		g_pd3dDevice,
		L"../../data/checker_with_numbers.bmp",
		NULL, NULL, &m_pTexSRV[1],
		NULL)))
	{
		H(hr);
		return false;
	}
	if (FAILED(hr = D3DX11CreateShaderResourceViewFromFile(
		g_pd3dDevice,
		L"../../data/Splash.jpg",
		NULL, NULL, &m_pTexSRV[2],
		NULL)))
	{
		H(hr);
		return false;
	}
	if (FAILED(hr = D3DX11CreateShaderResourceViewFromFile(
		g_pd3dDevice,
		L"../../data/Back.bmp",
		NULL, NULL, &m_pTexSRV[3],
		NULL)))
	{
		H(hr);
		return false;
	}

	D3D11_SHADER_RESOURCE_VIEW_DESC srvd;
	m_pTexSRV[0]->GetDesc(&srvd);
	int iMaxLod = srvd.Texture2D.MipLevels;

	D3D11_SAMPLER_DESC sd;
	ZeroMemory(&sd, sizeof(D3D11_SAMPLER_DESC));
	sd.Filter = D3D11_FILTER_ANISOTROPIC;
	sd.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
	sd.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
	sd.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
	sd.BorderColor[0] = 0.0f;
	sd.BorderColor[1] = 0.0f;
	sd.BorderColor[2] = 0.0f;
	sd.BorderColor[3] = 1.0f;
	sd.MaxAnisotropy = 16;
	sd.MinLOD = 0;
	sd.MaxLOD = 0;
	if (FAILED(hr = g_pd3dDevice->CreateSamplerState(&sd, &m_pSamplerState)))
	{
		H(hr);
		return false;
	}

#pragma region g_pVertexShader
	m_Object.g_pVertexShader.Attach(
		LoadVertexShaderFile(g_pd3dDevice,
			L"Shader.hlsl",
			m_Object.g_pVSBlob.GetAddressOf()));
#pragma endregion
#pragma region g_pPixelShader
	m_Object.g_pPixelShader.Attach(
		DX::LoadPixelShaderFile(g_pd3dDevice, L"Shader.hlsl"));

	m_pShadowPixelShader=
		DX::LoadPixelShaderFile(g_pd3dDevice,
			L"Shader.hlsl",
			"PS_Shadow");
#pragma endregion
	//#pragma region g_pGeometryShader
	//	m_Object.g_pGeometryShader.Attach(
	//		DX::LoadGeometryShaderFile(g_pd3dDevice, L"Shader.hlsl"));
	//#pragma endregion
#pragma region g_pInputlayout
	D3D11_INPUT_ELEMENT_DESC layout[] =
	{
		{ "POSITION",0,DXGI_FORMAT_R32G32B32_FLOAT,0,0,D3D11_INPUT_PER_VERTEX_DATA,0 },
		{ "NORMAL",0,DXGI_FORMAT_R32G32B32_FLOAT,0,12,D3D11_INPUT_PER_VERTEX_DATA,0 },
		{ "COLOR",0,DXGI_FORMAT_R32G32B32A32_FLOAT,0,24,D3D11_INPUT_PER_VERTEX_DATA,0 },
		{ "TEXCOORD",0,DXGI_FORMAT_R32G32_FLOAT,0,40,D3D11_INPUT_PER_VERTEX_DATA,0 },
	};
	UINT numElements = sizeof(layout) / sizeof(layout[0]);
	m_Object.g_pInputlayout.Attach(CreateInputlayout(g_pd3dDevice,
		layout, numElements,
		m_Object.g_pVSBlob.Get()));
#pragma endregion
#pragma region g_pVertexBuffer

	srand(time(NULL));
#pragma region g_pVertexCenter
	//PNCT_VERTEX m_VertexCenter[MAX_VERTEX];
	// FRONT   BACK
	// 0   1   4    5
	//
	// 3   2   6    7
	m_VertexCenter[0] = PNCT_VERTEX(D3DXVECTOR3(-1.0f, 1.0f, -1.0f), D3DXVECTOR3(0.0f, 0.0f, -1.0f), D3DXVECTOR4(1.0f, 0.0f, 0.0f, 1.0f), D3DXVECTOR2(0.0f, 0.0f));
	m_VertexCenter[1] = PNCT_VERTEX(D3DXVECTOR3(1.0f, 1.0f, -1.0f), D3DXVECTOR3(0.0f, 0.0f, -1.0f), D3DXVECTOR4(1.0f, 0.0f, 0.0f, 1.0f), D3DXVECTOR2(1.0f, 0.0f));
	m_VertexCenter[2] = PNCT_VERTEX(D3DXVECTOR3(1.0f, -1.0f, -1.0f), D3DXVECTOR3(0.0f, 0.0f, -1.0f), D3DXVECTOR4(1.0f, 0.0f, 0.0f, 1.0f), D3DXVECTOR2(1.0f, 1.0f));
	m_VertexCenter[3] = PNCT_VERTEX(D3DXVECTOR3(-1.0f, -1.0f, -1.0f), D3DXVECTOR3(0.0f, 0.0f, -1.0f), D3DXVECTOR4(1.0f, 0.0f, 0.0f, 1.0f), D3DXVECTOR2(0.0f, 1.0f));
	// �޸�
	m_VertexCenter[4] = PNCT_VERTEX(D3DXVECTOR3(1.0f, 1.0f, 1.0f), D3DXVECTOR3(0.0f, 0.0f, 1.0f), D3DXVECTOR4(0.0f, 0.0f, 0.0f, 1.0f), D3DXVECTOR2(0.0f, 0.0f));
	m_VertexCenter[5] = PNCT_VERTEX(D3DXVECTOR3(-1.0f, 1.0f, 1.0f), D3DXVECTOR3(0.0f, 0.0f, 1.0f), D3DXVECTOR4(0.0f, 1.0f, 0.0f, 1.0f), D3DXVECTOR2(1.0f, 0.0f));
	m_VertexCenter[6] = PNCT_VERTEX(D3DXVECTOR3(-1.0f, -1.0f, 1.0f), D3DXVECTOR3(0.0f, 0.0f, 1.0f), D3DXVECTOR4(0.0f, 1.0f, 0.0f, 1.0f), D3DXVECTOR2(1.0f, 1.0f));
	m_VertexCenter[7] = PNCT_VERTEX(D3DXVECTOR3(1.0f, -1.0f, 1.0f), D3DXVECTOR3(0.0f, 0.0f, 1.0f), D3DXVECTOR4(0.0f, 1.0f, 0.0f, 1.0f), D3DXVECTOR2(0.0f, 1.0f));

	// ����
	m_VertexCenter[8] = PNCT_VERTEX(D3DXVECTOR3(1.0f, 1.0f, -1.0f), D3DXVECTOR3(1.0f, 0.0f, 0.0f), D3DXVECTOR4(0.0f, 0.0f, 1.0f, 1.0f), D3DXVECTOR2(0.0f, 0.0f));
	m_VertexCenter[9] = PNCT_VERTEX(D3DXVECTOR3(1.0f, 1.0f, 1.0f), D3DXVECTOR3(1.0f, 0.0f, 0.0f), D3DXVECTOR4(0.0f, 0.0f, 1.0f, 1.0f), D3DXVECTOR2(1.0f, 0.0f));
	m_VertexCenter[10] = PNCT_VERTEX(D3DXVECTOR3(1.0f, -1.0f, 1.0f), D3DXVECTOR3(1.0f, 0.0f, 0.0f), D3DXVECTOR4(0.0f, 0.0f, 1.0f, 1.0f), D3DXVECTOR2(1.0f, 1.0f));
	m_VertexCenter[11] = PNCT_VERTEX(D3DXVECTOR3(1.0f, -1.0f, -1.0f), D3DXVECTOR3(1.0f, 0.0f, 0.0f), D3DXVECTOR4(0.0f, 0.0f, 1.0f, 1.0f), D3DXVECTOR2(0.0f, 1.0f));

	// �����ʸ�
	m_VertexCenter[12] = PNCT_VERTEX(D3DXVECTOR3(-1.0f, 1.0f, 1.0f), D3DXVECTOR3(-1.0f, 0.0f, 0.0f), D3DXVECTOR4(1.0f, 1.0f, 0.0f, 1.0f), D3DXVECTOR2(0.0f, 0.0f));
	m_VertexCenter[13] = PNCT_VERTEX(D3DXVECTOR3(-1.0f, 1.0f, -1.0f), D3DXVECTOR3(-1.0f, 0.0f, 0.0f), D3DXVECTOR4(1.0f, 1.0f, 0.0f, 1.0f), D3DXVECTOR2(1.0f, 0.0f));
	m_VertexCenter[14] = PNCT_VERTEX(D3DXVECTOR3(-1.0f, -1.0f, -1.0f), D3DXVECTOR3(-1.0f, 0.0f, 0.0f), D3DXVECTOR4(1.0f, 1.0f, 0.0f, 1.0f), D3DXVECTOR2(1.0f, 1.0f));
	m_VertexCenter[15] = PNCT_VERTEX(D3DXVECTOR3(-1.0f, -1.0f, 1.0f), D3DXVECTOR3(-1.0f, 0.0f, 0.0f), D3DXVECTOR4(1.0f, 1.0f, 0.0f, 1.0f), D3DXVECTOR2(0.0f, 1.0f));

	// ����
	m_VertexCenter[16] = PNCT_VERTEX(D3DXVECTOR3(-1.0f, 1.0f, 1.0f), D3DXVECTOR3(0.0f, 1.0f, 0.0f), D3DXVECTOR4(1.0f, 0.0f, 1.0f, 1.0f), D3DXVECTOR2(0.0f, 0.0f));
	m_VertexCenter[17] = PNCT_VERTEX(D3DXVECTOR3(1.0f, 1.0f, 1.0f), D3DXVECTOR3(0.0f, 1.0f, 0.0f), D3DXVECTOR4(1.0f, 0.0f, 1.0f, 1.0f), D3DXVECTOR2(1.0f, 0.0f));
	m_VertexCenter[18] = PNCT_VERTEX(D3DXVECTOR3(1.0f, 1.0f, -1.0f), D3DXVECTOR3(0.0f, 1.0f, 0.0f), D3DXVECTOR4(1.0f, 0.0f, 1.0f, 1.0f), D3DXVECTOR2(1.0f, 1.0f));
	m_VertexCenter[19] = PNCT_VERTEX(D3DXVECTOR3(-1.0f, 1.0f, -1.0f), D3DXVECTOR3(0.0f, 1.0f, 0.0f), D3DXVECTOR4(1.0f, 0.0f, 1.0f, 1.0f), D3DXVECTOR2(0.0f, 1.0f));

	// �Ʒ���
	m_VertexCenter[20] = PNCT_VERTEX(D3DXVECTOR3(-1.0f, -1.0f, -1.0f), D3DXVECTOR3(0.0f, -1.0f, 0.0f), D3DXVECTOR4(0.0f, 1.0f, 1.0f, 1.0f), D3DXVECTOR2(0.0f, 0.0f));
	m_VertexCenter[21] = PNCT_VERTEX(D3DXVECTOR3(1.0f, -1.0f, -1.0f), D3DXVECTOR3(0.0f, -1.0f, 0.0f), D3DXVECTOR4(0.0f, 1.0f, 1.0f, 1.0f), D3DXVECTOR2(1.0f, 0.0f));
	m_VertexCenter[22] = PNCT_VERTEX(D3DXVECTOR3(1.0f, -1.0f, 1.0f), D3DXVECTOR3(0.0f, -1.0f, 0.0f), D3DXVECTOR4(0.0f, 1.0f, 1.0f, 1.0f), D3DXVECTOR2(1.0f, 1.0f));
	m_VertexCenter[23] = PNCT_VERTEX(D3DXVECTOR3(-1.0f, -1.0f, 1.0f), D3DXVECTOR3(0.0f, -1.0f, 0.0f), D3DXVECTOR4(0.0f, 1.0f, 1.0f, 1.0f), D3DXVECTOR2(0.0f, 1.0f));


	int iNumVertex = sizeof(m_VertexCenter) / sizeof(m_VertexCenter[0]);
	m_Object.g_pVertexBuffer.Attach(
		DX::CreateBuffer(g_pd3dDevice, m_VertexCenter,
			iNumVertex, sizeof(PNCT_VERTEX),
			D3D11_BIND_VERTEX_BUFFER));
#pragma endregion g_pVertexCenter
#pragma region g_pVertexSide
	m_VertexSide[0] = PNCT_VERTEX(D3DXVECTOR3(0.0f, 1.0f, -1.0f), D3DXVECTOR3(0.0f, 0.0f, -1.0f), D3DXVECTOR4(1.0f, 0.0f, 0.0f, 1.0f), D3DXVECTOR2(0.0f, 0.0f));
	m_VertexSide[1] = PNCT_VERTEX(D3DXVECTOR3(2.0f, 1.0f, -1.0f), D3DXVECTOR3(0.0f, 0.0f, -1.0f), D3DXVECTOR4(1.0f, 0.0f, 0.0f, 1.0f), D3DXVECTOR2(1.0f, 0.0f));
	m_VertexSide[2] = PNCT_VERTEX(D3DXVECTOR3(2.0f, -1.0f, -1.0f), D3DXVECTOR3(0.0f, 0.0f, -1.0f), D3DXVECTOR4(1.0f, 0.0f, 0.0f, 1.0f), D3DXVECTOR2(1.0f, 1.0f));
	m_VertexSide[3] = PNCT_VERTEX(D3DXVECTOR3(0.0f, -1.0f, -1.0f), D3DXVECTOR3(0.0f, 0.0f, -1.0f), D3DXVECTOR4(1.0f, 0.0f, 0.0f, 1.0f), D3DXVECTOR2(0.0f, 1.0f));
	// �޸�
	m_VertexSide[4] = PNCT_VERTEX(D3DXVECTOR3(2.0f, 1.0f, 1.0f), D3DXVECTOR3(0.0f, 0.0f, 1.0f), D3DXVECTOR4(0.0f, 0.0f, 0.0f, 1.0f), D3DXVECTOR2(0.0f, 0.0f));
	m_VertexSide[5] = PNCT_VERTEX(D3DXVECTOR3(0.0f, 1.0f, 1.0f), D3DXVECTOR3(0.0f, 0.0f, 1.0f), D3DXVECTOR4(0.0f, 1.0f, 0.0f, 1.0f), D3DXVECTOR2(1.0f, 0.0f));
	m_VertexSide[6] = PNCT_VERTEX(D3DXVECTOR3(0.0f, -1.0f, 1.0f), D3DXVECTOR3(0.0f, 0.0f, 1.0f), D3DXVECTOR4(0.0f, 1.0f, 0.0f, 1.0f), D3DXVECTOR2(1.0f, 1.0f));
	m_VertexSide[7] = PNCT_VERTEX(D3DXVECTOR3(2.0f, -1.0f, 1.0f), D3DXVECTOR3(0.0f, 0.0f, 1.0f), D3DXVECTOR4(0.0f, 1.0f, 0.0f, 1.0f), D3DXVECTOR2(0.0f, 1.0f));

	// ����
	m_VertexSide[8] = PNCT_VERTEX(D3DXVECTOR3(2.0f, 1.0f, -1.0f), D3DXVECTOR3(1.0f, 0.0f, 0.0f), D3DXVECTOR4(0.0f, 0.0f, 1.0f, 1.0f), D3DXVECTOR2(0.0f, 0.0f));
	m_VertexSide[9] = PNCT_VERTEX(D3DXVECTOR3(2.0f, 1.0f, 1.0f), D3DXVECTOR3(1.0f, 0.0f, 0.0f), D3DXVECTOR4(0.0f, 0.0f, 1.0f, 1.0f), D3DXVECTOR2(1.0f, 0.0f));
	m_VertexSide[10] = PNCT_VERTEX(D3DXVECTOR3(2.0f, -1.0f, 1.0f), D3DXVECTOR3(1.0f, 0.0f, 0.0f), D3DXVECTOR4(0.0f, 0.0f, 1.0f, 1.0f), D3DXVECTOR2(1.0f, 1.0f));
	m_VertexSide[11] = PNCT_VERTEX(D3DXVECTOR3(2.0f, -1.0f, -1.0f), D3DXVECTOR3(1.0f, 0.0f, 0.0f), D3DXVECTOR4(0.0f, 0.0f, 1.0f, 1.0f), D3DXVECTOR2(0.0f, 1.0f));

	// �����ʸ�
	m_VertexSide[12] = PNCT_VERTEX(D3DXVECTOR3(0.0f, 1.0f, 1.0f), D3DXVECTOR3(-1.0f, 0.0f, 0.0f), D3DXVECTOR4(1.0f, 1.0f, 0.0f, 1.0f), D3DXVECTOR2(0.0f, 0.0f));
	m_VertexSide[13] = PNCT_VERTEX(D3DXVECTOR3(0.0f, 1.0f, -1.0f), D3DXVECTOR3(-1.0f, 0.0f, 0.0f), D3DXVECTOR4(1.0f, 1.0f, 0.0f, 1.0f), D3DXVECTOR2(1.0f, 0.0f));
	m_VertexSide[14] = PNCT_VERTEX(D3DXVECTOR3(0.0f, -1.0f, -1.0f), D3DXVECTOR3(-1.0f, 0.0f, 0.0f), D3DXVECTOR4(1.0f, 1.0f, 0.0f, 1.0f), D3DXVECTOR2(1.0f, 1.0f));
	m_VertexSide[15] = PNCT_VERTEX(D3DXVECTOR3(0.0f, -1.0f, 1.0f), D3DXVECTOR3(-1.0f, 0.0f, 0.0f), D3DXVECTOR4(1.0f, 1.0f, 0.0f, 1.0f), D3DXVECTOR2(0.0f, 1.0f));

	// ����
	m_VertexSide[16] = PNCT_VERTEX(D3DXVECTOR3(0.0f, 1.0f, 1.0f), D3DXVECTOR3(0.0f, 1.0f, 0.0f), D3DXVECTOR4(1.0f, 0.0f, 1.0f, 1.0f), D3DXVECTOR2(0.0f, 0.0f));
	m_VertexSide[17] = PNCT_VERTEX(D3DXVECTOR3(2.0f, 1.0f, 1.0f), D3DXVECTOR3(0.0f, 1.0f, 0.0f), D3DXVECTOR4(1.0f, 0.0f, 1.0f, 1.0f), D3DXVECTOR2(1.0f, 0.0f));
	m_VertexSide[18] = PNCT_VERTEX(D3DXVECTOR3(2.0f, 1.0f, -1.0f), D3DXVECTOR3(0.0f, 1.0f, 0.0f), D3DXVECTOR4(1.0f, 0.0f, 1.0f, 1.0f), D3DXVECTOR2(1.0f, 1.0f));
	m_VertexSide[19] = PNCT_VERTEX(D3DXVECTOR3(0.0f, 1.0f, -1.0f), D3DXVECTOR3(0.0f, 1.0f, 0.0f), D3DXVECTOR4(1.0f, 0.0f, 1.0f, 1.0f), D3DXVECTOR2(0.0f, 1.0f));

	// �Ʒ���
	m_VertexSide[20] = PNCT_VERTEX(D3DXVECTOR3(0.0f, -1.0f, -1.0f), D3DXVECTOR3(0.0f, -1.0f, 0.0f), D3DXVECTOR4(0.0f, 1.0f, 1.0f, 1.0f), D3DXVECTOR2(0.0f, 0.0f));
	m_VertexSide[21] = PNCT_VERTEX(D3DXVECTOR3(2.0f, -1.0f, -1.0f), D3DXVECTOR3(0.0f, -1.0f, 0.0f), D3DXVECTOR4(0.0f, 1.0f, 1.0f, 1.0f), D3DXVECTOR2(1.0f, 0.0f));
	m_VertexSide[22] = PNCT_VERTEX(D3DXVECTOR3(2.0f, -1.0f, 1.0f), D3DXVECTOR3(0.0f, -1.0f, 0.0f), D3DXVECTOR4(0.0f, 1.0f, 1.0f, 1.0f), D3DXVECTOR2(1.0f, 1.0f));
	m_VertexSide[23] = PNCT_VERTEX(D3DXVECTOR3(0.0f, -1.0f, 1.0f), D3DXVECTOR3(0.0f, -1.0f, 0.0f), D3DXVECTOR4(0.0f, 1.0f, 1.0f, 1.0f), D3DXVECTOR2(0.0f, 1.0f));

	iNumVertex = sizeof(m_VertexSide) / sizeof(m_VertexSide[0]);
	m_pVBSide =
		DX::CreateBuffer(g_pd3dDevice, m_VertexSide,
			iNumVertex, sizeof(PNCT_VERTEX),
			D3D11_BIND_VERTEX_BUFFER);
#pragma endregion

#pragma endregion
#pragma region g_pIndexBuffer
	DWORD m_IndexList[36];
	int iIndex = 0;
	m_IndexList[iIndex++] = 0; 	m_IndexList[iIndex++] = 1; 	m_IndexList[iIndex++] = 2; 	m_IndexList[iIndex++] = 0;	m_IndexList[iIndex++] = 2; 	m_IndexList[iIndex++] = 3;
	m_IndexList[iIndex++] = 4; 	m_IndexList[iIndex++] = 5; 	m_IndexList[iIndex++] = 6; 	m_IndexList[iIndex++] = 4;	m_IndexList[iIndex++] = 6; 	m_IndexList[iIndex++] = 7;
	m_IndexList[iIndex++] = 8; 	m_IndexList[iIndex++] = 9; 	m_IndexList[iIndex++] = 10; m_IndexList[iIndex++] = 8;	m_IndexList[iIndex++] = 10; m_IndexList[iIndex++] = 11;
	m_IndexList[iIndex++] = 12; m_IndexList[iIndex++] = 13; m_IndexList[iIndex++] = 14; m_IndexList[iIndex++] = 12;	m_IndexList[iIndex++] = 14; m_IndexList[iIndex++] = 15;
	m_IndexList[iIndex++] = 16; m_IndexList[iIndex++] = 17; m_IndexList[iIndex++] = 18; m_IndexList[iIndex++] = 16;	m_IndexList[iIndex++] = 18; m_IndexList[iIndex++] = 19;
	m_IndexList[iIndex++] = 20; m_IndexList[iIndex++] = 21; m_IndexList[iIndex++] = 22; m_IndexList[iIndex++] = 20;	m_IndexList[iIndex++] = 22; m_IndexList[iIndex++] = 23;

	m_iNumIndex = sizeof(m_IndexList) / sizeof(m_IndexList[0]);
	m_Object.g_pIndexBuffer.Attach(
		CreateBuffer(g_pd3dDevice, m_IndexList,
			m_iNumIndex, sizeof(DWORD),
			D3D11_BIND_INDEX_BUFFER));
#pragma endregion
#pragma region g_pConstantBuffer
	ZeroMemory(&m_cbData, sizeof(VS_CONSTANT_BUFFER));
	m_cbData.time = 1.0f;
	m_Object.g_pConstantBuffer.Attach(
		CreateBuffer(g_pd3dDevice, &m_cbData,
			1, sizeof(VS_CONSTANT_BUFFER),
			D3D11_BIND_CONSTANT_BUFFER,
			false));
#pragma endregion
//

	D3DXMatrixIdentity(&m_matWorld[0]);
	D3DXMatrixIdentity(&m_matWorld[1]);
	D3DXMatrixIdentity(&m_matWorld[2]);
	D3DXMatrixIdentity(&m_matWorld[3]);

	// USER VIEW
	m_vEye[0] = D3DXVECTOR3(0.0f, 20.0f, -20.0f);
	m_vAt[0] = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	m_vUp = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
	D3DXMatrixLookAtLH(&m_matView[0], &m_vEye[0],&m_vAt[0], &m_vUp);

	// FRONT VIEW
	m_vEye[1] = D3DXVECTOR3(0.0f, 0.0f, -10.0f);
	m_vAt[1] = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	D3DXMatrixLookAtLH(&m_matView[1],&m_vEye[1],&m_vAt[1],&m_vUp);
	m_vEye[2] = D3DXVECTOR3(10.0f, 0.0f, 0.0f);
	m_vAt[2] = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	D3DXMatrixLookAtLH(&m_matView[2],&m_vEye[2],&m_vAt[2],&m_vUp);
	m_vEye[3] = D3DXVECTOR3(0.0f, 10.0f, -1.0f);
	m_vAt[3] = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	D3DXMatrixLookAtLH(&m_matView[3],&m_vEye[3],&m_vAt[3],&m_vUp);

	m_fAspet = 800.0f / 600.0f;
	m_fFov = D3DX_PI * 0.25f;
	float fNear = 1.0f;
	float fFar = 100.f;
	D3DXMatrixPerspectiveFovLH(&m_matProj[0],m_fFov, m_fAspet, fNear, fFar);
	
	float fAspet = 600.0f / 800.0f;
	D3DXMatrixOrthoLH(&m_matProj[1], 2.0f, 2.0f,0, 100.0f);

	D3DXMatrixOrthoOffCenterLH(&m_matProj[2], 
		-10, 50.0f/2.0f,
		-10, 50.0f/2.0f,
		0, 100.0f);

	return true;
}
bool	Sample::Frame() {
	static float ftime = 0.0f;
	static int iIndex = 0;
	ftime += g_fSecPerFrame;
	m_cbData.time = cosf(m_Timer.m_fAccumulation);// *0.5f + 0.5f;
												  //m_cbData.time *= 0.5f;

	D3DXMATRIX matRotation[4];
	D3DXMATRIX matScale[4];
	D3DXMATRIX matTranslate[4];
	D3DXMATRIX matWorld[4];
	// 0 �� ������Ʈ
	D3DXMatrixRotationY(&matRotation[0], ftime);
	m_matWorld[0] = matRotation[0];
	m_matWorld[0]._42 = 3.0f;
	
	D3DXMatrixShadow(&m_matShadow,
		&D3DXVECTOR4(50.0f, 50.0f, 50.0f, 1.0f),
		&D3DXPLANE(0, 1, 0, -0.1f));

	// 1 �� ������Ʈ
	D3DXMatrixRotationY(&matRotation[1], ftime);
	D3DXMatrixTranslation(&matTranslate[1], 5, 3, 0);
	matWorld[1] = matRotation[1] * matTranslate[1];
	D3DXMATRIX mat = m_matWorld[0];
	mat._42 = 0;
	m_matWorld[1] = matWorld[1] * mat;
	// 2 �� ������Ʈ
	D3DXMatrixRotationY(&matRotation[2], ftime*-3.3f);
	D3DXMatrixTranslation(&matTranslate[2], 0, 3, 3);
	matWorld[2] = matRotation[2] * matTranslate[2];

	// ���� ������Ʈ ��� = �ڽ��� ��� * �θ��� ��� 
	m_matWorld[2] = matWorld[2] *matRotation[2] *m_matWorld[1];

	//// 3 �� ������Ʈ
	//D3DXMatrixRotationY(&matRotation[3], ftime*-3.0f);
	//D3DXMatrixTranslation(&matTranslate[3], 0, 0, -3);
	//D3DXMatrixScaling(&matScale[3], 2.0f, 0.5f, 0.5f);
	//matWorld[3] = matScale[3] * matRotation[3] * matTranslate[3];
	////D3DXMatrixInverse(&invScale, NULL, &matScale[1]);
	//// ���� ������Ʈ ��� = �ڽ��� ��� * �θ��� ��� 
	//m_matWorld[3] = matWorld[3] * invScale * m_matWorld[1];
	if (I_Input.KeyCheck(DIK_PRIOR)==KEY_UP)
	{
		m_iProjIndex++;
		if (m_iProjIndex >= 3)m_iProjIndex = 0;
	}
	
	if (I_Input.KeyCheck(DIK_INSERT))
	{
		m_fAspet +=0.4f * g_fSecPerFrame;
		m_fAngle += 0.1f * g_fSecPerFrame;
		//m_fAspet = 800.0f / 600.0f;
	}
	if (I_Input.KeyCheck(DIK_DELETE))
	{
		m_fAspet -= 0.4f* g_fSecPerFrame;
		m_fAngle -= 0.1f * g_fSecPerFrame;
	}	
	m_fFov = D3DX_PI * m_fAngle;
	D3DXMatrixPerspectiveFovLH(&m_matProj[0],
		m_fFov, m_fAspet, 1, 100.0f);


	if (I_Input.KeyCheck(DIK_HOME) == KEY_UP)
	{
		m_iViewIndex++;
		if (m_iViewIndex >= 4)m_iViewIndex = 0;
	}
	if (I_Input.KeyCheck(DIK_END) == KEY_UP)
	{
		m_iObjectIndex++;
		if (m_iObjectIndex >= 3)m_iObjectIndex = 0;
	}

	if (I_Input.KeyCheck(DIK_LEFT))
	{
		m_vEye[m_iViewIndex].x += g_fSecPerFrame * 10.0f;
	}
	if (I_Input.KeyCheck(DIK_RIGHT))
	{
		m_vEye[m_iViewIndex].x -= g_fSecPerFrame * 10.0f;
	}
	if (I_Input.KeyCheck(DIK_UP))
	{
		m_vEye[m_iViewIndex].y += g_fSecPerFrame * 10.0f;
	}
	if (I_Input.KeyCheck(DIK_DOWN))
	{
		m_vEye[m_iViewIndex].y -= g_fSecPerFrame * 10.0f;
	}
	m_vAt[m_iViewIndex].x = m_matWorld[m_iObjectIndex]._41;
	m_vAt[m_iViewIndex].y = m_matWorld[m_iObjectIndex]._42;
	m_vAt[m_iViewIndex].z = m_matWorld[m_iObjectIndex]._43;
	D3DXMatrixLookAtLH(&m_matView[m_iViewIndex],
		&m_vEye[m_iViewIndex], &m_vAt[m_iViewIndex], &m_vUp);

	D3DXMatrixTranslation(&m_matCameraWorld[0],
		m_vEye[1].x, m_vEye[1].y, m_vEye[1].z);
	D3DXMatrixTranslation(&m_matCameraWorld[1],
		m_vEye[2].x, m_vEye[2].y, m_vEye[2].z);
	D3DXMatrixTranslation(&m_matCameraWorld[2],
		m_vEye[3].x, m_vEye[3].y, m_vEye[3].z);

	return m_Object.Frame();
}
bool	Sample::Render() {
#pragma region D3D11_VIEWPORT
	if (I_Input.KeyCheck(DIK_F4))
	{
		ApplyDSS(g_pImmediateContext, TDxState::g_pDepthStencilDisableDSS);
	}

	D3D11_VIEWPORT vp[4];
	vp[0].Width = (FLOAT)m_dwWidth;
	vp[0].Height = (FLOAT)m_dwHeight;
	vp[0].MinDepth = 0.0f;
	vp[0].MaxDepth = 1.0f;
	vp[0].TopLeftX = 0;
	vp[0].TopLeftY = 0;
	vp[1].Width = (FLOAT)m_dwWidth / 2;
	vp[1].Height = (FLOAT)m_dwHeight / 2;
	vp[1].MinDepth = 0.0f;
	vp[1].MaxDepth = 1.0f;
	vp[1].TopLeftX = m_dwWidth / 2;
	vp[1].TopLeftY = 0;

	vp[3].Width = (FLOAT)m_dwWidth / 2;
	vp[3].Height = (FLOAT)m_dwHeight / 2;
	vp[3].MinDepth = 0.0f;
	vp[3].MaxDepth = 1.0f;
	vp[3].TopLeftX = 0;
	vp[3].TopLeftY = m_dwHeight / 2;

	vp[2].Width = (FLOAT)m_dwWidth / 2;
	vp[2].Height = (FLOAT)m_dwHeight / 2;
	vp[2].MinDepth = 0.0f;
	vp[2].MaxDepth = 1.0f;
	vp[2].TopLeftX = m_dwWidth / 2;
	vp[2].TopLeftY = m_dwHeight / 2;

	g_pImmediateContext->RSSetViewports(4, vp);
#pragma endregion

#pragma region ���� ���°�
	D3DXMatrixTranspose(&m_cbData.matView, &m_matView[m_iViewIndex]);
	D3DXMatrixTranspose(&m_cbData.matProj, &m_matProj[m_iProjIndex]);

	// ������Ƽ��� ������ƼŬ�� ����ϱ� ������ �����Ǿ� �Ѵ�.
	g_pImmediateContext->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
	g_pImmediateContext->IASetInputLayout(m_Object.g_pInputlayout.Get());

	UINT stride = sizeof(PNCT_VERTEX);
	UINT offset = 0;
	g_pImmediateContext->IASetVertexBuffers(0, 1, m_Object.g_pVertexBuffer.GetAddressOf(), &stride, &offset);
	g_pImmediateContext->IASetIndexBuffer(m_Object.g_pIndexBuffer.Get(), DXGI_FORMAT_R32_UINT, 0);
	g_pImmediateContext->VSSetConstantBuffers(0, 1, m_Object.g_pConstantBuffer.GetAddressOf());
	g_pImmediateContext->VSSetShader(m_Object.g_pVertexShader.Get(), NULL, 0);
	g_pImmediateContext->GSSetConstantBuffers(0, 1, m_Object.g_pConstantBuffer.GetAddressOf());
	g_pImmediateContext->GSSetShader(m_Object.g_pGeometryShader.Get(), NULL, 0);
	g_pImmediateContext->PSSetShader(m_Object.g_pPixelShader.Get(), NULL, 0);

	g_pImmediateContext->PSSetSamplers(0, 1, &m_pSamplerState);
#pragma endregion

#pragma region �������� ������Ʈ ���
	ApplyDSS(g_pImmediateContext, m_pNoStencilDSS.Get());
	g_pImmediateContext->OMSetBlendState(m_pSrcBlendState.Get(), 0, 0xffffffff);
	ApplyRS(g_pImmediateContext, TDxState::g_pCullSolidRS[2]);


	// �������� ������Ʈ �ٴ� 1�� , �ڽ� 3��
	for (int iVp = 0; iVp < 4; iVp++)
	{	
		D3DXMatrixTranspose(&m_cbData.matWorld, &m_matWorld[iVp]);
		if (iVp == 3)
		{
			D3DXMATRIX matWorld = m_matWorld[0];
			matWorld._42 = -1.0f;
			matWorld._11 = 20.0f;
			matWorld._33 = 20.0f;
			D3DXMatrixTranspose(&m_cbData.matWorld, &matWorld);
		}		
		g_pImmediateContext->UpdateSubresource(m_Object.g_pConstantBuffer.Get(), 0, NULL, &m_cbData, 0, 0);
		g_pImmediateContext->PSSetShaderResources(0, 1, &m_pTexSRV[iVp]);
		if (iVp != 3)
		{
			g_pImmediateContext->DrawIndexed(m_iNumIndex, 0, 0);
		}
		else
		{
			g_pImmediateContext->DrawIndexed(6, 24, 0);
		}
	}	
#pragma endregion 

#pragma region ȭ�鿡 ��ο� ���� �ʰ� ���ٽ� ���ۿ���  ���
	// �ٴ��� ������ �ڽ� ������Ʈ ���ٽ� ���
	g_pImmediateContext->OMSetBlendState(m_pNoSrcBlendState.Get(), 0, 0xffffffff);
	ApplyDSS(g_pImmediateContext, TDxState::g_pDepthStencilAddDSS);
	ApplyRS(g_pImmediateContext, TDxState::g_pCullSolidRS[m_Object.m_iCullMode]);
	for (int iObj = 0; iObj < 3; iObj++)
	{
		D3DXMATRIX matShadow = m_matWorld[iObj] * m_matShadow;
		D3DXMatrixTranspose(&m_cbData.matWorld,	&matShadow);		
		g_pImmediateContext->UpdateSubresource(	m_Object.g_pConstantBuffer.Get(), 0, NULL, &m_cbData, 0, 0);
		g_pImmediateContext->PSSetShaderResources(0, 1, &m_pTexSRV[iObj]);
		g_pImmediateContext->DrawIndexed(m_iNumIndex, 0, 0);
	}	
#pragma endregion 

#pragma region ���ٽ� ���� ����Ͽ� ������ ��� ������	
	g_pImmediateContext->OMSetDepthStencilState(m_pNotEqualDSS.Get(),	0x00);
	g_pImmediateContext->OMSetBlendState(m_pSrcBlendState.Get(),0, 0xffffffff);
	D3DXMATRIX matIdentity;
	D3DXMatrixIdentity(&matIdentity);
	D3DXMatrixTranspose(&m_cbData.matView, &matIdentity);
	D3DXMatrixTranspose(&m_cbData.matProj, &matIdentity);	
	matIdentity._43 = 1.5f;
	D3DXMatrixTranspose(&m_cbData.matWorld, &matIdentity);		
	g_pImmediateContext->UpdateSubresource(m_Object.g_pConstantBuffer.Get(), 0, NULL, &m_cbData, 0, 0);
	ApplyRS(g_pImmediateContext, TDxState::g_pCullSolidRS[m_Object.m_iCullMode]);
	g_pImmediateContext->PSSetShader(m_pShadowPixelShader, NULL, 0);
	g_pImmediateContext->DrawIndexed(6, 0, 0);
	
#pragma endregion 
	return true;
}
bool	Sample::Release() {
	if (m_pTexSRV[0]) m_pTexSRV[0]->Release();
	if (m_pTexSRV[1]) m_pTexSRV[1]->Release();
	if (m_pTexSRV[2]) m_pTexSRV[2]->Release();
	if (m_pTexSRV[3]) m_pTexSRV[3]->Release();
	if (m_pSamplerState) m_pSamplerState->Release();
	m_Object.Release();
	SAFE_RELEASE(m_pVBSide);
	SAFE_RELEASE(m_pShadowPixelShader);
	return true;
}

Sample::Sample()
{
	m_iProjIndex = m_iObjectIndex = m_iViewIndex = 0;
	m_fAngle = 0.25f;
}


Sample::~Sample()
{
}
TCORE_RUN(_T("Sample Lib"), 800, 600)