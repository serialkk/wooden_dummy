#include "Sample.h"
ID3D11Texture2D* Sample::GetTexture2DFromFile(
	LPCWSTR filename,
	D3DX11_IMAGE_LOAD_INFO* pLoadInfo)
{
	ID3D11Texture2D* texture = NULL;
	ID3D11Resource*  pRes = NULL;

	HRESULT hr = D3DX11CreateTextureFromFile(
		m_pd3dDevice,
		filename,
		pLoadInfo,
		NULL,
		&pRes,
		NULL);
	if (FAILED(hr))
	{
		H(hr);
		return NULL;
	}
	pRes->QueryInterface(__uuidof(ID3D11Texture2D), (LPVOID*)&texture);
	pRes->Release();
	return texture;
}
void Sample::WriteDotPixel(ID3D11Texture2D* pTex)
{
	D3D11_TEXTURE2D_DESC td;
	pTex->GetDesc(&td);
	D3D11_MAPPED_SUBRESOURCE map;
	if (SUCCEEDED(GetContext()->Map(
		(ID3D11Resource*)pTex, 0, D3D11_MAP_READ_WRITE,
		0, &map)))
	{
		BYTE* pData = (BYTE*)map.pData;
		for (UINT y = 0; y < td.Height; y++)
		{
			for (UINT x = 0; x < td.Width; x++)
			{
				BYTE r, g, b, a;
				r = pData[0];
				g = pData[1];
				b = pData[2];
				a = pData[3];
				if (r <= 100 && g <= 100 && b <= 100)
				{
					*pData++ = 255;
					*pData++ = 0;
					*pData++ = 0;
					*pData++ = 255;
				}
				else
				{
					pData += 4;
				}
			}
			//pData += map.RowPitch;
		}
		GetContext()->Unmap(pTex, 0);
	}
}
bool	Sample::Init()
{
	HRESULT hr;
	D3DX11_IMAGE_LOAD_INFO loadInfo;
	ZeroMemory(&loadInfo, sizeof(D3DX11_IMAGE_LOAD_INFO));
	loadInfo.Width = 512;
	loadInfo.Height = 512;
	loadInfo.Depth = D3DX11_DEFAULT;
	loadInfo.FirstMipLevel = 0;
	loadInfo.MipLevels = 0;	
	loadInfo.Usage = D3D11_USAGE_STAGING;
	loadInfo.CpuAccessFlags = D3D11_CPU_ACCESS_WRITE | D3D11_CPU_ACCESS_READ;
	loadInfo.BindFlags = 0;
	loadInfo.MiscFlags = 0;
	loadInfo.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	loadInfo.Filter = D3DX11_FILTER_LINEAR;
	loadInfo.MipFilter = D3DX11_FILTER_LINEAR;
	m_TextureStaging = GetTexture2DFromFile(L"../../data/02.jpg",	&loadInfo);
	WriteDotPixel(m_TextureStaging);

	
	D3D11_TEXTURE2D_DESC m_tStaging;
	m_TextureStaging->GetDesc(&m_tStaging);
		
	m_tStaging.Usage = D3D11_USAGE_DEFAULT;
	m_tStaging.CPUAccessFlags = 0;
	//* �߿�
	m_tStaging.BindFlags = D3D11_BIND_SHADER_RESOURCE| D3D11_BIND_RENDER_TARGET;
	m_tStaging.MipLevels = m_tStaging.MipLevels;
	m_tStaging.MiscFlags = D3D11_RESOURCE_MISC_GENERATE_MIPS;

	if (FAILED(hr = g_pd3dDevice->CreateTexture2D(&m_tStaging, NULL, &m_TextureDefault)))
	{
		H(hr);
	}
	GetContext()->CopyResource(	m_TextureDefault,m_TextureStaging);

	if (m_TextureStaging)m_TextureStaging->Release();

	m_TextureDefault->GetDesc(&m_tDefault);
	
	D3D11_SHADER_RESOURCE_VIEW_DESC srv;
	ZeroMemory(&srv, sizeof(D3D11_SHADER_RESOURCE_VIEW_DESC));
	srv.Format = m_tDefault.Format;
	srv.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
	srv.Texture2D.MipLevels = m_tDefault.MipLevels;
	if (FAILED(hr = g_pd3dDevice->CreateShaderResourceView(
		m_TextureDefault, &srv, &m_pTexSRV)))
	{
		H(hr);
	}
	if (m_TextureDefault) m_TextureDefault->Release();
	GetContext()->GenerateMips(m_pTexSRV);

	

#pragma region g_pVertexShader
	m_Object.g_pVertexShader =
		LoadVertexShaderFile(g_pd3dDevice,
			L"Shader.hlsl",
			&m_Object.g_pVSBlob);
#pragma endregion
#pragma region g_pPixelShader
	m_Object.g_pPixelShader =
		DX::LoadPixelShaderFile(g_pd3dDevice, L"Shader.hlsl");
#pragma endregion
#pragma region g_pGeometryShader
	m_Object.g_pGeometryShader =
		DX::LoadGeometryShaderFile(g_pd3dDevice, L"Shader.hlsl");
#pragma endregion
#pragma region g_pInputlayout
	D3D11_INPUT_ELEMENT_DESC layout[] =
	{
		{ "POSITION",0,DXGI_FORMAT_R32G32B32_FLOAT,0,0,D3D11_INPUT_PER_VERTEX_DATA,0 },
		{ "COLOR",0,DXGI_FORMAT_R32G32B32A32_FLOAT,0,12,D3D11_INPUT_PER_VERTEX_DATA,0 },
		{ "TEXCOORD",0,DXGI_FORMAT_R32G32_FLOAT,0,28,D3D11_INPUT_PER_VERTEX_DATA,0 },
	};
	UINT numElements = sizeof(layout) / sizeof(layout[0]);
	m_Object.g_pInputlayout = CreateInputlayout(g_pd3dDevice,
		layout, numElements,
		m_Object.g_pVSBlob);
#pragma endregion
#pragma region g_pVertexBuffer
	SimpleVertex vertices[] =
	{
		//  0, 1, 2
		//  0, 2, 3
		// 0,��,��
		-0.5f, 0.5f, 0.0f,	1.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f,
		// 1,��,��
		0.5f, 0.5f, 0.0f,	0.0f, 1.0f, 0.0f, 1.0f, 1.0f, 0.0f,
		// 2,��,��
		0.5f, -0.5f, 0.0f,	0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f,
		// 3,��,��
		-0.5f, -0.5f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f, 0.0f, 1.0f,
	};

	int iNumVertex = sizeof(vertices) / sizeof(vertices[0]);
	m_Object.g_pVertexBuffer =
		DX::CreateBuffer(g_pd3dDevice, vertices,
			iNumVertex, sizeof(SimpleVertex),
			D3D11_BIND_VERTEX_BUFFER);
#pragma endregion
#pragma region g_pIndexBuffer
	DWORD indices[] = { 0,1,2, 0,2,3, };
	int iNumIndex = sizeof(indices) / sizeof(indices[0]);
	m_Object.g_pIndexBuffer =
		CreateBuffer(g_pd3dDevice, indices,
			iNumIndex, sizeof(DWORD),
			D3D11_BIND_INDEX_BUFFER);
#pragma endregion
#pragma region g_pConstantBuffer
	m_Object.g_pConstantBuffer =
		CreateBuffer(g_pd3dDevice, &m_cbData,
			1, sizeof(VS_CONSTANT_BUFFER),
			D3D11_BIND_CONSTANT_BUFFER,
			false);
#pragma endregion

	/*HRESULT hr;
	
	if (FAILED(hr = D3DX11CreateShaderResourceViewFromFile(
		g_pd3dDevice,
		L"../../data/checker_with_numbers.bmp", 
		NULL, NULL, &m_pTexSRV, 
		NULL)))
	{
		H(hr);
		return false;
	}*/
	
	Update();
	return true;
}
void Sample::Update()
{
	HRESULT hr;
	D3D11_SHADER_RESOURCE_VIEW_DESC srvd;
	m_pTexSRV->GetDesc(&srvd);
	int iMaxLod = srvd.Texture2D.MipLevels;

	if (m_pSamplerState)m_pSamplerState->Release();
	D3D11_SAMPLER_DESC sd;
	ZeroMemory(&sd, sizeof(D3D11_SAMPLER_DESC));
	sd.Filter = D3D11_FILTER_ANISOTROPIC;
	sd.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
	sd.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
	sd.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
	sd.BorderColor[0] = 0.0f;
	sd.BorderColor[1] = 0.0f;
	sd.BorderColor[2] = 0.0f;
	sd.BorderColor[3] = 1.0f;
	sd.MaxAnisotropy = 16;
	sd.MinLOD = m_iMinLod;
	sd.MaxLOD = sd.MinLOD + 1;
	if (FAILED(hr = g_pd3dDevice->CreateSamplerState(&sd, &m_pSamplerState)))
	{
		H(hr);
		return;
	}
}
bool	Sample::Frame() {

	if (I_Input.KeyCheck(DIK_M) == KEY_UP)
	{
		m_iMinLod++;
		if (m_tDefault.MipLevels <= m_iMinLod)
		{
			m_iMinLod = 0;
		}
		Update();
	}
	m_cbData.r = 1.0f;
	m_cbData.g = 1.0f;
	m_cbData.b = 1.0f;
	m_cbData.a = 1.0f;
	m_cbData.x = cosf(m_Timer.m_fAccumulation)*0.5f+0.5f;
	m_cbData.y = sinf(m_Timer.m_fAccumulation)*0.5f + 0.5f;
	g_pImmediateContext->UpdateSubresource(
		m_Object.g_pConstantBuffer,
		0, NULL, &m_cbData, 0, 0);
	return m_Object.Frame();
}
bool	Sample::Render() {
	g_pImmediateContext->PSSetConstantBuffers(0, 1,
		&m_Object.g_pConstantBuffer);

	g_pImmediateContext->PSSetShaderResources(0, 1,
			&m_pTexSRV);
	
	g_pImmediateContext->PSSetSamplers(0, 1,
		&m_pSamplerState);

	m_Object.Render(g_pImmediateContext,
		sizeof(SimpleVertex), 6);
	return true;
}
bool	Sample::Release() {

	if (m_pTexSRV) m_pTexSRV->Release();
	if (m_pSamplerState) m_pSamplerState->Release();
	m_Object.Release();
	return true;
}

Sample::Sample()
{
	m_cbData.r = 1.0f;
	m_cbData.g = 0.0f;
	m_cbData.b = 0.0f;
	m_cbData.a = 1.0f;
	m_iMinLod = 0;
}


Sample::~Sample()
{
}
TCORE_RUN(_T("Sample Lib"), 800, 600)