#pragma once
#include "Tcore.h"
struct SimpleVertex
{
	float x, y, z;
	float r, g, b, a;
	float u, v;
};
struct VS_CONSTANT_BUFFER
{
	float r, g, b, a;
	float x, y, z, w;
};
class Sample : public TCore
{
public:
	TDXObject			m_Object;
	VS_CONSTANT_BUFFER	m_cbData;
	ID3D11Texture2D*    m_TextureStaging;
	ID3D11Texture2D*    m_TextureDefault;
	ID3D11ShaderResourceView*   m_pTexSRV;
	ID3D11SamplerState*			m_pSamplerState;

	D3D11_TEXTURE2D_DESC m_tDefault;
	int					m_iMinLod;

public:
	bool	Init();
	bool	Frame();
	bool	Render();
	bool	Release();
	void	Update();
	void WriteDotPixel(ID3D11Texture2D* pTex);
	ID3D11Texture2D* GetTexture2DFromFile(
		LPCWSTR filename,
		D3DX11_IMAGE_LOAD_INFO* pLoadInfo);
	Sample();
	virtual ~Sample();
};

