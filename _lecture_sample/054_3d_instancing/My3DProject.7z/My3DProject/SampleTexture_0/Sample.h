#pragma once
class Sample
{
public:
	Sample();
	virtual ~Sample();
};

