#pragma once
#include "Tcore.h"
#include "TVector.h"

struct VS_CONSTANT_BUFFER
{
	TVector4 vColor;	// c0						
	float fC5_X;
	float fTime;
	float fC5_Z;
	float fC5_W;
};
struct SimpleVertex
{
	TVector3 Pos;
	TVector4 Color0;
};
class Sample : public TCore
{
public:
	TDXObject   m_Rect;
	SimpleVertex vertices[4];
	VS_CONSTANT_BUFFER  m_cb;	
public:
	bool		Init();
	bool		Frame();
	bool		Render();
	bool		Release();
public:
	Sample();
	virtual ~Sample();
};

