#include "TSprite.h"
bool TSprite::Init()
{
	return true;
}

bool TSprite::Release()
{
	return true;
}
bool  TSprite::Load(T_STR strShaderFile,
	T_STR strTextureFile,
	ID3D11BlendState* pBlendState)
{
	TShape::Create( g_pd3dDevice,
					strShaderFile.c_str(),	
					strTextureFile.c_str() );

	//m_Sprite.SetAttribute(30.0f, 2.0f, 4, 4);
	m_pBlendState = pBlendState;
	return true;
}
void  TSprite::SetAttribute(float fLifeTime,
	float fAnimTime,
	int iWidth,
	int iHeight)
{
	m_fLifeTime = fLifeTime;
	m_fAnimTime = fAnimTime;
	m_iNumTexture = iWidth * iHeight;
	m_fSecPerRender = m_fAnimTime / m_iNumTexture;

	float fStepW, fStepH;
	fStepW = 1.0f / iWidth;
	fStepH = 1.0f / iHeight;

	m_rtUV.resize(iWidth*iHeight);
	for (int iRow = 0; iRow < iHeight; iRow++)
	{
		for (int iCol = 0; iCol <iWidth; iCol++)
		{
			m_rtUV[iRow*iWidth+iCol].x = iCol*fStepW;
			m_rtUV[iRow*iWidth + iCol].y = iRow* fStepH;
			m_rtUV[iRow*iWidth + iCol].z = fStepW;
			m_rtUV[iRow*iWidth + iCol].w = fStepH;
		}
	}
}
bool TSprite::Frame()
{
	Update(m_fElapsedTime, m_fTempTime, m_iApplyIndex);	
	/*if (m_fLifeTime <= m_fElapsedTime)
	{
		m_fFadeOutValue = 1.0f;
	}
	if (m_bFadeOut==false && m_fLifeTime <= 3.0f+m_fElapsedTime)
	{
		m_bFadeOut = true;
		m_fFadeOutValue = 1.0f;
	}
	if (m_bFadeOut == true)
	{
		m_fFadeOutValue -= g_fSecPerFrame / 3.0f;
	}*/
	return true;
}
void TSprite::Update(   float&  fElapsedTime, 
						float&  fTempTime,
						UINT& iApply)
{
	fElapsedTime += g_fSecPerFrame;
	fTempTime += g_fSecPerFrame;
	if (fTempTime > m_fSecPerRender)
	{
		if (++iApply >= m_iNumTexture)
		{
			iApply = 0;
		}
		fTempTime = fTempTime - m_fSecPerRender;
	}
	
}
bool TSprite::Render(ID3D11DeviceContext* pContext, int iApply)
{
	if (m_bRender == false) return true;	
	m_VertexList[0].t = D3DXVECTOR2(
		m_rtUV[iApply].x,
		m_rtUV[iApply].y);
	m_VertexList[1].t =
		D3DXVECTOR2(m_rtUV[iApply].x + m_rtUV[iApply].z,
			m_rtUV[iApply].y);
	m_VertexList[3].t = D3DXVECTOR2(
		m_rtUV[iApply].x,
		m_rtUV[iApply].y + m_rtUV[iApply].w);
	m_VertexList[2].t = D3DXVECTOR2(
		m_rtUV[iApply].x + m_rtUV[iApply].z,
		m_rtUV[iApply].y + m_rtUV[iApply].w);
	pContext->UpdateSubresource(m_Object.g_pVertexBuffer.Get(),
		0, NULL, &m_VertexList.at(0), 0, 0);

	//m_cbData.Color = D3DXVECTOR4(1,1,1,m_fFadeOutValue);
	ApplyBS(pContext, m_pBlendState);
	PreRender(pContext);
	PostRender(pContext);
	return true;
}
TSprite::TSprite()
{
	m_iApplyIndex = 0;
	m_fElapsedTime = 0.0f;
	m_fTempTime = 0.0f;
	m_bFadeOut = false;
	m_bRender = true;
	m_fFadeOutValue = 1.0f;
	m_cFadeOutColor = D3DXVECTOR4(1, 1, 1, 1.0f);
}


TSprite::~TSprite()
{
}
