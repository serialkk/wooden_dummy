#pragma once
#include "Tcore.h"
#include "TShape.h"
#include "TCamera.h"
#include <memory>
#include "TParticleSystem.h"

#define MAX_CNT 10

class Sample : public TCore
{
public:
	TParticleSystem				m_ParticleSystem;	
	ComPtr<ID3D11BlendState>	m_pAlphaBlend;
	TCamera		m_Camera;	
	D3DXMATRIX m_matWorld;
public:
	D3DXVECTOR3 Circle(float fRadius, float fValue);
	bool	Init();
	bool	Frame();
	bool	Render();
	bool	Release();
	Sample();
	virtual ~Sample();
};

