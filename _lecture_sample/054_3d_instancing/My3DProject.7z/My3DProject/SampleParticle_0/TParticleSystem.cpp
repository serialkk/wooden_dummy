#include "TParticleSystem.h"
#include "TSpriteMgr.h"


TParticle::TParticle()
{
	m_fTempTime = 0.0f;
	float fValue = (rand() & RAND_MAX) / (float)RAND_MAX;

	m_vInitPos = D3DXVECTOR3(	0,
								0,
								0);

	m_vPos = D3DXVECTOR3(0,	0,0);
	
	m_vAdd = D3DXVECTOR3( sinf(rand()), cosf(rand()), 0);
	m_vColor.x = (rand() & RAND_MAX) / (float)RAND_MAX;
	m_vColor.y = (rand() & RAND_MAX) / (float)RAND_MAX;
	m_vColor.z = (rand() & RAND_MAX) / (float)RAND_MAX;
	m_vColor.w = (rand() & RAND_MAX) / (float)RAND_MAX;

	m_fElapsedTime = 0.0f;
	m_fLifeTime = rand() % 10;
	m_bRender = true;

	m_iSpriteID = (rand() % 4) +1;
	//m_pSprite = I_SpriteMgr.GetPtr(m_iSpriteID);
};
void TParticleSystem::Add(TParticle& obj)
{
	m_Particle.push_back(obj);
}
void TParticleSystem::Frame()
{
	for (int iObj = 0; iObj < m_Particle.size(); iObj++)
	{
		D3DXVECTOR3 vPos = Circle( 1.0f, g_fAccumulation);
		m_Particle[iObj].m_vPos += vPos;

		TSprite* pSprite = I_SpriteMgr.GetPtr(m_Particle[iObj].m_iSpriteID);
		pSprite->Update(m_Particle[iObj].m_fElapsedTime,
			m_Particle[iObj].m_fTempTime, 
			m_Particle[iObj].m_iApplyIndex );
	}
}
bool TParticleSystem::Render(ID3D11DeviceContext* pContext)
{
	for (int iObj = 0; iObj < m_Particle.size(); iObj++)
	{
		TSprite* pSprite = I_SpriteMgr.GetPtr(m_Particle[iObj].m_iSpriteID);
		m_matWorld._41 = m_Particle[iObj].m_vPos.x;
		m_matWorld._42 = m_Particle[iObj].m_vPos.y;
		m_matWorld._43 = m_Particle[iObj].m_vPos.z;
		pSprite->SetMatrix(&m_matWorld, &m_matView, &m_matProj);
		pSprite->m_cbData.Color = m_Particle[iObj].m_vColor;
		pSprite->Render(pContext, m_Particle[iObj].m_iApplyIndex);
	}
	return true;
}
D3DXVECTOR3 TParticleSystem::Circle(float fRadius, float fValue)
{
	D3DXVECTOR3 vReturn;
	vReturn.x = fRadius * cosf(fValue);
	vReturn.y = fRadius * sin(fValue);
	vReturn.z = 0.0f;
	return vReturn;
}
void   TParticleSystem::SetMatrix(D3DXMATRIX* matWorld,
	D3DXMATRIX* matView,
	D3DXMATRIX* matProj)
{
	if (matWorld != NULL)
	{
		m_matWorld = *matWorld;
	}
	D3DXMatrixInverse(&m_matWorld, NULL, matView);
	m_matWorld._41 = 0;
	m_matWorld._42 = 0;
	m_matWorld._43 = 0;
	m_matWorld._44 = 1;
	m_matView = *matView;
	m_matProj = *matProj;
}

TParticleSystem::TParticleSystem()
{
	TParticle obj;
	m_Particle.push_back(obj);
}


TParticleSystem::~TParticleSystem()
{
}
