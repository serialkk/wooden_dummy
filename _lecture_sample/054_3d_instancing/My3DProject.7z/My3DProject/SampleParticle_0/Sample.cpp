#include "Sample.h"

bool	Sample::Init()
{
	UINT iIndex = I_SpriteMgr.Add( L"blend.hlsl",
					 L"../../data/pung_yellow.dds",
					 TDxState::g_pAddBlend);
	TSprite* pSprite = I_SpriteMgr.GetPtr(iIndex);
	pSprite->SetAttribute(30.0f, 16.0f, 4, 4 );
	
	iIndex = I_SpriteMgr.Add(L"blend.hlsl",
		L"../../data/checker_with_numbers.bmp",
		TDxState::g_pSrcColorBlend);
	pSprite = I_SpriteMgr.GetPtr(iIndex);
	pSprite->SetAttribute(30.0f, 4.0f, 2, 2);

	iIndex = I_SpriteMgr.Add(L"blend.hlsl",
		L"../../data/fire_5.dds",
		TDxState::g_pAlphaBlend);
	pSprite = I_SpriteMgr.GetPtr(iIndex);
	pSprite->SetAttribute(30.0f, 1.0f, 4,4);

	iIndex = I_SpriteMgr.Add(L"blend.hlsl",
		L"../../data/frost.dds",
		TDxState::g_pAlphaBlend);
	pSprite = I_SpriteMgr.GetPtr(iIndex);
	pSprite->SetAttribute(30.0f, 1.0f, 4, 4);
	

	m_Camera.Create(m_pd3dDevice);
	m_ParticleSystem.Init();
	return true;
}
bool	Sample::Frame() 
{		
	m_Camera.Update(D3DXVECTOR4(0, 0, 0, 0));

	if (I_Input.KeyCheck(DIK_F7) == KEY_UP)
	{
		TParticle obj;
		m_ParticleSystem.Add(obj);
	}

	m_ParticleSystem.Frame();
	return true;
}

bool	Sample::Render()
{

	m_ParticleSystem.SetMatrix(NULL, 
			&m_Camera.m_matView, 
			&m_Camera.m_matProj);
	m_ParticleSystem.Render( g_pImmediateContext);
	return true;
}
bool	Sample::Release() {	
	m_ParticleSystem.Release();
	return true;
}

Sample::Sample()
{

}


Sample::~Sample()
{
}
TCORE_RUN(_T("Sample Lib"), 800, 600)