#pragma once
#include "TStd.h"
#include "TSpriteMgr.h"

class TParticle
{
public:
	D3DXVECTOR3 m_vInitPos;
	D3DXVECTOR3 m_vPos;
	D3DXVECTOR3 m_vAdd;
	D3DXVECTOR4 m_vColor;
	float       m_fElapsedTime;
	float       m_fLifeTime;
	float       m_bRender;
	UINT		m_iSpriteID;
	UINT		m_iApplyIndex;
	float		m_fTempTime;
	TSprite*	m_pSprite;
public:
	TParticle();
	~TParticle() {};
};

class TParticleSystem
{
public:
	vector<TParticle>  m_Particle;
	D3DXMATRIX m_matWorld;
	D3DXMATRIX m_matView;
	D3DXMATRIX m_matProj;

	int  m_iApplyIndex;
	bool m_bFadeOut;
	bool m_bRender;
	float m_fFadeOutValue;
	D3DXVECTOR4 m_cFadeOutColor;
	// x,y,z(width),w(height)
	float m_fLifeTime; //  �����ֱ�
	float m_fAnimTime; //  ��ü ������ 1�� �ݺ� �ð�
	float m_fElapsedTime;
	float m_fTempTime;
	float m_iNumTexture;
	float m_fSecPerRender;
	bool        Init() {
		return true;
	}
	void        Frame();
	void		Add(TParticle& obj);
	bool		Render(ID3D11DeviceContext* pContext);
	bool		Release() { return true; }

	void        SetMatrix( D3DXMATRIX* matWorld,
							D3DXMATRIX* matView,
							D3DXMATRIX* matProj);

	D3DXVECTOR3 Circle(float fRadius, float fValue);
public:
	TParticleSystem();
	virtual ~TParticleSystem();
};

