#pragma once
#include "TShape.h"
#include "TStd.h"
using namespace DX;


class TSprite : public TPlaneShape
{
public:
	T_STR				 m_strName;
	UINT				 m_iIndex;
	vector<D3DXVECTOR4>  m_rtUV;
	ID3D11BlendState*    m_pBlendState;
	UINT  m_iApplyIndex;
	bool m_bFadeOut;
	bool m_bRender;
	float m_fFadeOutValue;
	D3DXVECTOR4 m_cFadeOutColor;	
	// x,y,z(width),w(height)
	float m_fLifeTime; //  �����ֱ�
	float m_fAnimTime; //  ��ü ������ 1�� �ݺ� �ð�
	float m_fElapsedTime;
	float m_fTempTime;
	float m_iNumTexture;
	float m_fSecPerRender;
public:
	void  SetAttribute(float fLifeTime=5.0f,
		float fAnimTime = 1.0f,
		int iWidth = 1,		
		int iHeight = 1);
	bool Render(ID3D11DeviceContext* pContext,int iApply);
	bool  Init();	
	bool  Frame();
	bool  Release();
	void  Update(	float&  fElapsedTime,
					float&  fTempTime,
					UINT& iApply);
	bool  Load(T_STR strLoadFile) {		return true;	}
	bool  Load(T_STR strShaderFile,
		T_STR strTextureFile,
		ID3D11BlendState* pBlendState);
public:
	TSprite();
	~TSprite();
};

