#include "TSpriteMgr.h"
int	   TSpriteMgr::Add(
	T_STR strShaderFile,
	T_STR strTextureFile,
	ID3D11BlendState* pBlendState)
{
	//// �ߺ� ����
	TCHAR Dirve[MAX_PATH] = { 0, };
	TCHAR Dir[MAX_PATH] = { 0, };
	TCHAR Name[MAX_PATH] = { 0, };
	TCHAR Ext[MAX_PATH] = { 0, };
	TCHAR szFileName[MAX_PATH] = { 0, };

	if (!strTextureFile.empty())
	{
		_tsplitpath_s(strTextureFile.c_str(),
			Dirve, Dir, Name, Ext);
		_stprintf_s(szFileName, _T("%s%s"),
			Name, Ext);

		TSprite* pStrite;
		for (TItor itor = m_Map.begin();
		itor != m_Map.end();
			itor++)
		{
			pStrite = (TSprite*)(*itor).second;

			if (!_tcsicmp(pStrite->m_strName.c_str(),
				szFileName))
			{
				return (*itor).first;
			}
		}


	}
	TSprite* pStrite = new TSprite;
	if (pStrite == NULL) return -1;
	pStrite->Init();
	pStrite->m_strName = szFileName;
	pStrite->Load(	strShaderFile,
					strTextureFile,
					pBlendState);

	m_Map.insert(make_pair(++m_iCurIndex,
		pStrite));
	return m_iCurIndex;
}

int TSpriteMgr::Load( T_STR fileName )
{
	// �ߺ� ����
	TCHAR Dirve[MAX_PATH] = {0, };
	TCHAR Dir[MAX_PATH] = {0, };
	TCHAR Name[MAX_PATH] = {0, };
	TCHAR Ext[MAX_PATH] = {0, };
	TCHAR szFileName[MAX_PATH] = {0, };

	if( !fileName.empty() )
	{
		_tsplitpath_s( fileName.c_str(),
			Dirve, Dir, Name, Ext );
		_stprintf_s( szFileName, _T("%s%s"),
			Name, Ext );
		
		TSprite* pStrite;
		for( TItor itor = m_Map.begin(); 
		 itor != m_Map.end();
		 itor++ )
		{
			pStrite = (TSprite*)(*itor).second;
			
			if( !_tcsicmp(pStrite->m_strName.c_str(),
				szFileName ))
			{
				return (*itor).first;
			}
		}


	}
	TSprite* pStrite = new TSprite;
	if( pStrite == NULL ) return -1;
	pStrite->Init();
	pStrite->m_strName = szFileName;
	pStrite->Load(fileName );

	m_Map.insert( make_pair(++m_iCurIndex,
						    pStrite) );
	return m_iCurIndex;

}
TSprite* TSpriteMgr::GetPtr( int iIndex )
{
	TItor itor = m_Map.find( iIndex );
	if( itor == m_Map.end() ) return NULL;
	TSprite* pStrite = (*itor).second;
	return pStrite;
}
TSpriteMgr::TSpriteMgr(void)
{
	m_iCurIndex = 0;
}

bool	TSpriteMgr::Init()
{
	return true;
}

bool	TSpriteMgr::Frame(){
	return true;
}
bool	TSpriteMgr::Render(){
	return true;
}
bool	TSpriteMgr::Release(){
	TSprite* pStrite;
	for( TItor itor = m_Map.begin(); 
		 itor != m_Map.end();
		 itor++ )
	{
		pStrite = (TSprite*)(*itor).second;
		pStrite->Release();
		delete pStrite;
	}
	m_Map.clear();
	return true;
}
TSpriteMgr::~TSpriteMgr(void)
{
}
