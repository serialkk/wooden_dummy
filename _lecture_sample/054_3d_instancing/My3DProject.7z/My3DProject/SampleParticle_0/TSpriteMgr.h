#pragma once
#include "TSprite.h"
class TSpriteMgr : public TSingleton<TSpriteMgr>
{
private:
	friend class TSingleton<TSpriteMgr>;
public:
	typedef std::map<int, TSprite*>::iterator TItor;
	map<int, TSprite*>   m_Map;
	int					m_iCurIndex;
public:
	bool	Init();
	bool	Frame();
	bool	Render();
	bool	Release();
	int	    Load(T_STR strLoadFile);
	int	    Add(T_STR strShaderFile, 
				T_STR strTextureFile,
				ID3D11BlendState* pBlendtate = nullptr);

	TSprite*    GetPtr(int iIndex);

private:
	TSpriteMgr(void);
	~TSpriteMgr(void);
};
#define I_SpriteMgr TSpriteMgr::GetInstance()
