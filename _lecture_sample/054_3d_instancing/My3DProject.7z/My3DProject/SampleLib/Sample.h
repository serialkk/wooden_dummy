#pragma once
#include "Tcore.h"
struct SimpleVertex
{
	float x, y, z;
	float r,g,b,a;
};
struct VS_CONSTANT_BUFFER
{	
	float r, g, b, a;
};
class Sample : public TCore
{
public:
	TDXObject			m_Object;
	VS_CONSTANT_BUFFER	m_cbData;
public:
	bool	Init();
	bool	Frame();
	bool	Render();
	bool	Release();
	Sample();
	virtual ~Sample();
};

