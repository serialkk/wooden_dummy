#pragma once
#include <math.h>
struct TFloat2
{
	union
	{
		struct { float x, y; };
		float v[2];
	};
};
struct TFloat3
{
	union
	{
		struct { float x, y, z; };
		float v[3];
	};
};
struct TFloat4
{
	union
	{
		struct { float x, y, z, w; };
		float v[4];
	};
};

class TVector2 : public TFloat2
{
public:
	float		Length();
	TVector2    Normal();
	TVector2    operator + (TVector2 &v0);
	TVector2    operator - (TVector2 &v0);
	TVector2    operator * (float &fScale);
	bool		operator == (TVector2 & v0);
public:
	TVector2();
	TVector2(const TVector2& v0);
	TVector2(float fX, float fY);
	~TVector2();
};
class TVector3 : public TFloat3
{
public:
	float		Length();
	TVector3    Normal();
	TVector3    operator + (TVector3 &v0);
	TVector3    operator - (TVector3 &v0);
	TVector3    operator * (float &fScale);
	bool		operator == (TVector3 & v0);
public:
	TVector3();
	TVector3(const TVector3& v0);
	TVector3(float fX, float fY, float fZ);
	~TVector3();
};
class TVector4 : public TFloat4
{
public:
	float		Length();
	TVector4    Normal();
	TVector4    operator + (TVector4 &v0);
	TVector4    operator - (TVector4 &v0);
	TVector4    operator * (float &fScale);
	bool		operator == (TVector4 & v0);
public:
	TVector4();
	TVector4(const TVector4& v0);
	TVector4(float fX, float fY, float fZ, float fW);
	~TVector4();
};


