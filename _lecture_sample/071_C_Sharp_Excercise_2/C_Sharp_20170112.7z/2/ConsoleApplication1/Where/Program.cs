﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Where
{
    class User 
    {        
        public User() { }
    }
    class UserList<T> where T : class, new()
    {
        public List<T> list = new List<T>();
        public void Add(T user)
        {
            list.Add(user);
        }
        public T GetFind(int id)
        {
            //return list.Find(list, x => x == 1000 );            
            return null;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            UserList<User> userlist = new UserList<User>();
            User user1 = new User();
            userlist.Add(user1);
            userlist.Add(new User());


            int [] point = { 0,1,2,3};
            int iFind = Array.Find(point, x => x > 2);
            Console.WriteLine(iFind);


        }
    }
}
