﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace List_0
{
    public class User
    {
        public int id;
        public User(int index)
        {
            id = index;
        }
    }

    public class TList    {
        public List<User> m_iList = null;
        public void Print()
        {
            foreach( User user in m_iList)
            {
                Console.WriteLine(user.id);
            }
            //for( int i=0; i < m_iList.Count; i++)
            //{
            //    m_iList[i].id = i;
            //    Console.WriteLine(m_iList[i].id);
            //}
        }
        public TList()
        {
            m_iList = new List<User>();
        }
    }
    class Program    {
        static void Main(string[] args)
        {
            TList userList = new TList();
            User u1 = new User(999);
            userList.m_iList.Add(u1);
            userList.m_iList.Add( new User(888));
            //userList.Print();

            userList.m_iList.AddRange(userList.m_iList);
            //userList.Print();

            userList.m_iList.RemoveRange(2, 2);
            //userList.Print();

            string [] array = new string[] { "aa", "bb"};
            List<string> listArray = new List<string>();

            listArray = array.ToList();
            array = listArray.ToArray();


            bool bFind = listArray.Contains("bb");

            List<string> copy = listArray.GetRange(1, 2);
            string [] copyArray = copy.ToArray();

            

            listArray.Remove("aa");
            //userList.Print();
            listArray.RemoveAt(0);
            userList.Print();
        }        
    }
}
