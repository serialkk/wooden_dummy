#include "TCore.h"

bool TCore::GameInit()
{
	HRESULT hr;
	if (FAILED(CreateGIFactory()))
	{
		return 0;
	}
	if (FAILED(InitDevice()))
	{
		CleanupDevice();
		return 0;
	}
	if (FAILED(InitSwapChain()))
	{
		return 0;
	}
	if (FAILED(SetRenderTarget()))
	{
		return 0;
	}
	if (FAILED(SetViewPort()))
	{
		return 0;
	}

	m_Timer.Init();
	m_Input.Init();

	// font 
	IDXGISurface1*  pSurface;
	hr = g_pSwapChain->GetBuffer(0,
		__uuidof(IDXGISurface1),
		(LPVOID*)&pSurface);
	m_Font.Set(pSurface);
	pSurface->Release();

	Init();
	return true;
}
bool TCore::GameRelease()
{
	Release();
	m_Timer.Release();
	m_Input.Release();
	m_Font.Release();
	CleanupDevice();
	return true;
}
bool TCore::GameFrame()
{
	m_Timer.Frame();
	m_Input.Frame();
	PreFrame();
		Frame();
	PostFrame();
	return true;
}
bool TCore::PreRender()
{
	float ClearColor[4] = { 1.0f, 1.0f,1.0f, 1.0f }; //red,green,blue,alpha
	g_pImmediateContext->ClearRenderTargetView(
		g_pRenderTargetView,
		ClearColor);
	g_pImmediateContext->OMSetRenderTargets(1, &g_pRenderTargetView, NULL);
	// Set primitive topology
	g_pImmediateContext->IASetPrimitiveTopology(
		D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
	return true;
}
bool TCore::PostRender()
{
	g_pSwapChain->Present(0, 0);
	return true;
}
bool TCore::DrawDebug(TCHAR* pString, int iX, int iY)
{	
	return true;
}
bool TCore::DrawDebug()
{
	if (m_Input.KeyCheck(DIK_V) == KEY_HOLD)
	{	
		m_Font.Begin();
		RECT  rt = { 0, 0, 800, 600 };
		m_Font.m_TextFormat->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_CENTER);
		m_Font.DrawText(rt, m_Timer.m_csBuffer, D2D1::ColorF(0, 0, 0, 1.0f));
		m_Font.End();		
	}
	return true;
}
bool TCore::GameRender()
{
	PreRender();
		Render();
		m_Timer.Render();	
		m_Input.Render();
		DrawDebug();
	PostRender();
	return true;
}
bool TCore::GameRun()
{
	GameFrame();
	GameRender();
	return true;
};
void TCore::MsgEvent(MSG msg)
{
	m_Input.MsgEvent(msg);
};
TCore::TCore()
{
}


TCore::~TCore()
{
}
