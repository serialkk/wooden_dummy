#include "TTexture.h"

bool	TTexture::Init()
{
	return true;
}

bool	TTexture::Frame(){
	return true;
}
bool	TTexture::Render(){
	return true;
}
bool	TTexture::Release(){	
	return true;
}

bool TTexture::Load(	T_STR fileName )
{	
	return true;
}
TTexture::TTexture(void)
{
	m_strName = _T("");
}


TTexture::~TTexture(void)
{
}
