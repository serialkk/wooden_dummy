#pragma once
#include "Tcore.h"
#include "TDXHelper.h"
using namespace DX;

class Sample : public TCore
{
public:
	TDXHelper   m_Rect;
public:
	bool		Init();
	bool		Render();
	bool		Release();
public:
	Sample();
	virtual ~Sample();
};

