#include "Sample.h"
using namespace DX;

struct TVector3
{
	float x, y, z;
	TVector3::TVector3(
		float fx, float fy, float fz)
	{
		x = fx;
		y = fy;
		z = fz;
	}
};
struct TVector4
{
	float x, y, z, w;
	TVector4::TVector4(
		float fx, float fy, float fz, float fw)
	{
		x = fx;
		y = fy;
		z = fz;
		w = fw;
	}
};
struct SimpleVertex
{
	TVector3 Pos;
	TVector4 Color0;	
};

bool Sample::Init()
{
#pragma region RECT
	m_Rect.LoadVertexShaderFile(g_pd3dDevice,L"VertexShader.hlsl");
	m_Rect.LoadPixelShaderFile(g_pd3dDevice,L"PixelShader.hlsl");
	D3D11_INPUT_ELEMENT_DESC layout[] =
	{
		{ "POSITION",0,DXGI_FORMAT_R32G32B32_FLOAT,0,0,D3D11_INPUT_PER_VERTEX_DATA,0 },
		{ "COLOR",0,DXGI_FORMAT_R32G32B32A32_FLOAT,0,12,D3D11_INPUT_PER_VERTEX_DATA,0 },
	};
	UINT numElements =	sizeof(layout) / sizeof(layout[0]);
	m_Rect.CreateInputlayout(g_pd3dDevice,layout, numElements);

	SimpleVertex vertices[] =
	{
		//  0, 1, 2
		//  0, 2, 3
		// 0,��,��
		TVector3(-0.5f, 0.5f, 0.0f),	
		TVector4(1.0f, 0.0f, 0.0f, 1.0f),
		// 1,��,��
		TVector3(0.5f, 0.5f, 0.0f),	TVector4(0.0f, 1.0f, 0.0f, 1.0f),
		// 2,��,��
		TVector3(0.5f, -0.5f, 0.0f),	TVector4(0.0f, 0.0f, 1.0f, 1.0f),
		// 3,��,��
		TVector3(-0.5f, -0.5f, 0.0f),TVector4(1.0f, 1.0f, 0.0f, 1.0f),
	};
	int iNumVertex = sizeof(vertices) / sizeof(vertices[0]);
	m_Rect.CreateVertexBuffer(g_pd3dDevice, vertices,
		iNumVertex, sizeof(SimpleVertex));

	DWORD indices[] ={	0,1,2,0,2,3,	};
	int iNumIndex = sizeof(indices) / sizeof(indices[0]);
	m_Rect.CreateIndexBuffer(g_pd3dDevice, indices,
		iNumIndex, sizeof(DWORD));

#pragma endregion
	return true;
}
bool Sample::Render()
{
	m_Rect.Render(g_pImmediateContext,
		sizeof(SimpleVertex),6);	
	return true;
}
bool Sample::Release()
{	
	return true;
}
Sample::Sample()
{
}


Sample::~Sample()
{
}

TCORE_RUN(_T("Sample Win"), 800, 600)