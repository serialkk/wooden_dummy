#pragma once
#include <d3dx11.h>
#include <D3Dcompiler.h>
namespace DX
{
	class TDXHelper
	{
	public:
		TDXHelper::TDXHelper();
		TDXHelper::~TDXHelper();
		ID3D11Buffer*		g_pVertexBuffer;
		ID3D11Buffer*		g_pIndexBuffer;
		ID3D11Buffer*		g_pConstantBuffer;
		ID3D11VertexShader* g_pVertexShader;
		ID3D11PixelShader*  g_pPixelShader;
		ID3D11InputLayout*  g_pInputlayout;
		ID3DBlob*			g_pVSBlob;
		HRESULT   CompileShaderFromFile(WCHAR* szFileName, LPCSTR szEntryPoint, LPCSTR szShaderModel, ID3DBlob** ppBlobOut);
		HRESULT   LoadVertexShaderFile(
			ID3D11Device*  pd3dDevice,
			TCHAR* pLoadShaderFile);
		HRESULT   LoadPixelShaderFile(
			ID3D11Device*  pd3dDevice,
			TCHAR* pLoadShaderFile);
		HRESULT CreateInputlayout(
			ID3D11Device*  pd3dDevice,
			D3D11_INPUT_ELEMENT_DESC layout[],
			UINT numElements);
		HRESULT CreateVertexBuffer(
			ID3D11Device*  pd3dDevice,
			void *vertices,
			UINT iNumVertex,
			UINT iVertexSize
			);
		HRESULT CreateIndexBuffer(
			ID3D11Device*  pd3dDevice,
			void *indices,
			UINT iNumIndex,
			UINT iSize);
		bool Render(ID3D11DeviceContext*    pContext,
			UINT VertexSize, UINT VertexCount);
		void  Release();
	};
}
