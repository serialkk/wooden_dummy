#include "TDXHelper.h"

//ID3D11Buffer*		DX::g_pVertexBuffer;
//ID3D11Buffer*		DX::g_pIndexBuffer;
//ID3D11Buffer*		DX::g_pConstantBuffer;
//ID3D11VertexShader* DX::g_pVertexShader;
//ID3D11PixelShader*  DX::g_pPixelShader;
//ID3D11InputLayout*  DX::g_pInputlayout;
//ID3DBlob*			DX::g_pVSBlob;

namespace DX
{
	TDXHelper::TDXHelper()
	{
		g_pVertexBuffer =NULL;
		g_pIndexBuffer = NULL;
		g_pConstantBuffer = NULL;
		g_pVertexShader = NULL;
		g_pPixelShader = NULL;
		g_pInputlayout = NULL;
		g_pVSBlob = NULL;
	}
	TDXHelper::~TDXHelper()
	{
		Release();
	}
	HRESULT TDXHelper::CompileShaderFromFile(WCHAR* szFileName, LPCSTR szEntryPoint, LPCSTR szShaderModel, ID3DBlob** ppBlobOut)
	{
		HRESULT hr = S_OK;

		DWORD dwShaderFlags = D3DCOMPILE_ENABLE_STRICTNESS;
#if defined( DEBUG ) || defined( _DEBUG )
		// Set the D3DCOMPILE_DEBUG flag to embed debug information in the shaders.
		// Setting this flag improves the shader debugging experience, but still allows 
		// the shaders to be optimized and to run exactly the way they will run in 
		// the release configuration of this program.
		dwShaderFlags |= D3DCOMPILE_DEBUG;
#endif

		ID3DBlob* pErrorBlob;
		hr = D3DX11CompileFromFile(szFileName, NULL, NULL, szEntryPoint, szShaderModel,
			dwShaderFlags, 0, NULL, ppBlobOut, &pErrorBlob, NULL);
		if (FAILED(hr))
		{
			if (pErrorBlob != NULL)
				OutputDebugStringA((char*)pErrorBlob->GetBufferPointer());
			if (pErrorBlob) pErrorBlob->Release();
			return hr;
		}
		if (pErrorBlob) pErrorBlob->Release();

		return S_OK;
	}
	HRESULT   TDXHelper::LoadVertexShaderFile(
		ID3D11Device*  pd3dDevice,
		TCHAR* pLoadShaderFile)
	{
		HRESULT hr = S_OK;
		//ID3DBlob* pVSBlob = NULL;
		hr = CompileShaderFromFile(
			pLoadShaderFile,
			"VS",
			"vs_5_0",
			&g_pVSBlob);

		if (FAILED(hr))
		{
			MessageBox(NULL,
				L"The FX file cannot be compiled.  Please run this executable from the directory that contains the FX file.", L"Error", MB_OK);
			return hr;
		}
		// Create the vertex shader
		hr = pd3dDevice->CreateVertexShader(
			g_pVSBlob->GetBufferPointer(),
			g_pVSBlob->GetBufferSize(),
			NULL,
			&g_pVertexShader);
		if (FAILED(hr))
		{
			g_pVSBlob->Release();
			return hr;
		}
		return hr;
	};
	HRESULT   TDXHelper::LoadPixelShaderFile(
		ID3D11Device*  pd3dDevice,
		TCHAR* pLoadShaderFile)
	{
		HRESULT hr = S_OK;
		ID3DBlob* pPSBlob = NULL;
		hr = CompileShaderFromFile(
			pLoadShaderFile,
			"PS",
			"ps_5_0",
			&pPSBlob);
		if (FAILED(hr))
		{
			MessageBox(NULL,
				L"The FX file cannot be compiled.  Please run this executable from the directory that contains the FX file.", L"Error", MB_OK);
			return hr;
		}

		// Create the pixel shader
		hr = pd3dDevice->CreatePixelShader(pPSBlob->GetBufferPointer(), pPSBlob->GetBufferSize(), NULL, &g_pPixelShader);
		pPSBlob->Release();
		if (FAILED(hr))
			return hr;
		return hr;
	}

	HRESULT TDXHelper::CreateInputlayout(
		ID3D11Device*  pd3dDevice,
		D3D11_INPUT_ELEMENT_DESC layout[],
		UINT numElements)
	{
		HRESULT hr = S_OK;
		// Create the input layout
		hr = pd3dDevice->CreateInputLayout(layout,
			numElements, g_pVSBlob->GetBufferPointer(),
			g_pVSBlob->GetBufferSize(),
			&g_pInputlayout);
		if (FAILED(hr))
			return hr;
		return hr;
	}
	HRESULT TDXHelper::CreateVertexBuffer(
		ID3D11Device*  pd3dDevice,
		void *vertices,
		UINT iNumVertex,
		UINT iVertexSize)
	{
		HRESULT hr = S_OK;
		D3D11_BUFFER_DESC bd;
		ZeroMemory(&bd, sizeof(bd));
		bd.Usage = D3D11_USAGE_DEFAULT;
		bd.ByteWidth = iVertexSize * iNumVertex;
		bd.BindFlags = D3D11_BIND_VERTEX_BUFFER;
		bd.CPUAccessFlags = 0;
		D3D11_SUBRESOURCE_DATA InitData;
		ZeroMemory(&InitData, sizeof(InitData));
		InitData.pSysMem = vertices;
		hr = pd3dDevice->CreateBuffer(&bd, &InitData,
			&g_pVertexBuffer);
		if (FAILED(hr))
			return hr;
		return hr;
	}
	HRESULT TDXHelper::CreateIndexBuffer(
		ID3D11Device*  pd3dDevice,
		void *indices,
		UINT iNumIndex,
		UINT iSize)
	{
		HRESULT hr = S_OK;
		D3D11_BUFFER_DESC bd;
		ZeroMemory(&bd, sizeof(bd));
		D3D11_SUBRESOURCE_DATA InitData;
		ZeroMemory(&InitData, sizeof(InitData));

		bd.Usage = D3D11_USAGE_DEFAULT;
		bd.ByteWidth = iSize * iNumIndex;
		bd.BindFlags = D3D11_BIND_INDEX_BUFFER;
		InitData.pSysMem = indices;

		hr = pd3dDevice->CreateBuffer(&bd, &InitData,
			&g_pIndexBuffer);
		if (FAILED(hr))
			return hr;
		return hr;
	}
	bool TDXHelper::Render(
		ID3D11DeviceContext*    pContext,
		UINT VertexSize, UINT VertexCount)
	{
		pContext->IASetInputLayout(
			g_pInputlayout);
		// Set vertex buffer
		UINT stride = VertexSize;
		UINT offset = 0;
		pContext->IASetVertexBuffers(0, 1,
			&g_pVertexBuffer, &stride, &offset);
		// �ε��� ����
		pContext->IASetIndexBuffer(g_pIndexBuffer,
			DXGI_FORMAT_R32_UINT, 0);
		pContext->VSSetShader(g_pVertexShader, NULL, 0);
		pContext->PSSetShader(g_pPixelShader, NULL, 0);
		pContext->DrawIndexed(VertexCount, 0, 0);
		return true;
	}
	void  TDXHelper::Release()
	{
		if (g_pVertexBuffer) g_pVertexBuffer->Release();
		if (g_pIndexBuffer) g_pIndexBuffer->Release();
		if (g_pConstantBuffer) g_pConstantBuffer->Release();
		if (g_pVertexShader) g_pVertexShader->Release();
		if (g_pPixelShader) g_pPixelShader->Release();
		if (g_pInputlayout) g_pInputlayout->Release();
		if (g_pVSBlob) g_pVSBlob->Release();
		g_pVertexBuffer = NULL;
		g_pIndexBuffer = NULL;
		g_pConstantBuffer = NULL;
		g_pVertexShader = NULL;
		g_pPixelShader = NULL;
		g_pInputlayout = NULL;
		g_pVSBlob = NULL;
	}
}