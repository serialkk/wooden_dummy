#ifndef TBASIS_H
#define TBASIS_H
#pragma warning( disable:4005)
#include "TStructure.h"
#include "TTemplate.h"

using namespace TBASIS_BASE;

#endif //TBASIS_H